import { FeatherIcon } from "lucide-react";

interface LogoProps {
  className?: string;
}

export default function Logo({ className = "" }: LogoProps) {
  return (
    <div className={`flex items-center ${className}`}>
      <FeatherIcon className="w-6 h-6 mr-2 text-primary" />
      <span className="text-2xl font-bold text-primary">Gaming Pouls</span>
    </div>
  );
}
