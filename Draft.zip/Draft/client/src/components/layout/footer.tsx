import { Link } from "wouter";
import Logo from "@/components/ui/logo";
import { Facebook, Instagram, Youtube, Phone, Mail, Globe } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export default function Footer() {
  return (
    <footer className="bg-dark text-white pt-12 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          <div>
            <h3 className="text-lg font-bold mb-4">Gaming Pouls</h3>
            <p className="text-gray-300 mb-4">Premium quality gaming fowl for enthusiasts and breeders.</p>
            <div className="flex space-x-4">
              <button className="text-gray-300 hover:text-white">
                <Facebook className="h-5 w-5" />
              </button>
              <button className="text-gray-300 hover:text-white">
                <Instagram className="h-5 w-5" />
              </button>
              <button className="text-gray-300 hover:text-white">
                <Youtube className="h-5 w-5" />
              </button>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/">
                  <span className="text-gray-300 hover:text-white cursor-pointer">Home</span>
                </Link>
              </li>
              <li>
                <Link href="/male-pouls">
                  <span className="text-gray-300 hover:text-white cursor-pointer">Male Pouls</span>
                </Link>
              </li>
              <li>
                <Link href="/female-pouls">
                  <span className="text-gray-300 hover:text-white cursor-pointer">Female Pouls</span>
                </Link>
              </li>
              <li>
                <Link href="/egg-clusters">
                  <span className="text-gray-300 hover:text-white cursor-pointer">Egg Clusters</span>
                </Link>
              </li>
              <li>
                <Link href="/village-hens">
                  <span className="text-gray-300 hover:text-white cursor-pointer">Village Hens</span>
                </Link>
              </li>
              <li>
                <Link href="/chicks">
                  <span className="text-gray-300 hover:text-white cursor-pointer">Chicks</span>
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-4">Customer Service</h3>
            <ul className="space-y-2">
              <li><span className="text-gray-300 hover:text-white cursor-pointer">Shipping Policy</span></li>
              <li><span className="text-gray-300 hover:text-white cursor-pointer">Return Policy</span></li>
              <li><span className="text-gray-300 hover:text-white cursor-pointer">Terms of Service</span></li>
              <li><span className="text-gray-300 hover:text-white cursor-pointer">Privacy Policy</span></li>
              <li><span className="text-gray-300 hover:text-white cursor-pointer">FAQ</span></li>
              <li>
                <Link href="/contact">
                  <span className="text-gray-300 hover:text-white cursor-pointer">Contact Us</span>
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-4">Newsletter</h3>
            <p className="text-gray-300 mb-4">Subscribe to receive updates, special offers, and care tips.</p>
            <form className="flex">
              <Input 
                type="email" 
                placeholder="Your email address" 
                className="rounded-r-none" 
              />
              <Button type="submit" className="rounded-l-none">
                <Mail className="h-4 w-4" />
              </Button>
            </form>
          </div>
        </div>
        
        <div className="pt-8 border-t border-gray-700 text-center text-gray-400 text-sm">
          <p>&copy; {new Date().getFullYear()} Gaming Pouls. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
