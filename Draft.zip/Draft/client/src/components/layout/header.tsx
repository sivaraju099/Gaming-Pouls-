import { useState } from "react";
import { Link, useLocation } from "wouter";
import Logo from "@/components/ui/logo";
import { ShoppingCart, Menu } from "lucide-react";
import MobileMenu from "./mobile-menu";
import { useCart } from "@/components/cart/cart-provider";

export default function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { items, toggleCartOpen } = useCart();
  const [location, navigate] = useLocation();
  
  const cartItemsCount = items.reduce((total, item) => total + item.quantity, 0);

  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center cursor-pointer" onClick={() => navigate("/")}>
            <Logo />
          </div>
          
          {/* Main Navigation */}
          <nav className="hidden md:flex space-x-8">
            <div 
              className="font-medium hover:text-primary transition-colors cursor-pointer"
              onClick={() => navigate("/")}
            >
              Home
            </div>
            <div className="relative group">
              <button className="font-medium hover:text-primary transition-colors flex items-center">
                View the Pouls <span className="ml-1 text-xs">▼</span>
              </button>
              <div className="absolute left-0 mt-2 w-64 bg-white shadow-lg rounded-md opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 z-50">
                <div 
                  className="block px-4 py-2 hover:bg-gray-100 cursor-pointer"
                  onClick={() => navigate("/male-pouls")}
                >
                  Male Pouls
                </div>
                <div 
                  className="block px-4 py-2 hover:bg-gray-100 cursor-pointer font-bold text-primary flex items-center"
                  onClick={() => navigate("/champion-pouls")}
                >
                  Heavyweight Champions (3kg+)
                  <span className="ml-2 px-1.5 py-0.5 rounded bg-primary text-white text-xs">NEW</span>
                </div>
                <div 
                  className="block px-4 py-2 hover:bg-gray-100 cursor-pointer"
                  onClick={() => navigate("/female-pouls")}
                >
                  Female Pouls
                </div>
                <div 
                  className="block px-4 py-2 hover:bg-gray-100 cursor-pointer"
                  onClick={() => navigate("/egg-clusters")}
                >
                  Egg Clusters
                </div>
                <div 
                  className="block px-4 py-2 hover:bg-gray-100 cursor-pointer"
                  onClick={() => navigate("/village-hens")}
                >
                  Village Hens
                </div>
                <div 
                  className="block px-4 py-2 hover:bg-gray-100 cursor-pointer"
                  onClick={() => navigate("/chicks")}
                >
                  Baby Pouls (Chicks)
                </div>
              </div>
            </div>
            <div 
              className="font-medium hover:text-primary transition-colors cursor-pointer"
              onClick={() => navigate("/contact")}
            >
              Contact Us
            </div>
            <div 
              className="font-medium hover:text-primary transition-colors cursor-pointer"
              onClick={() => navigate("/help")}
            >
              Help
            </div>
            <div 
              className="font-medium hover:text-primary transition-colors cursor-pointer flex items-center"
              onClick={() => navigate("/admin/login")}
            >
              Admin
              <span className="ml-1 px-1.5 py-0.5 rounded bg-gray-200 text-gray-800 text-xs">Login</span>
            </div>
          </nav>
          
          {/* Cart and Mobile Menu Button */}
          <div className="flex items-center space-x-4">
            <button 
              onClick={toggleCartOpen}
              className="relative p-2"
              aria-label="Shopping Cart"
            >
              <ShoppingCart className="h-6 w-6" />
              {cartItemsCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-primary text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold">
                  {cartItemsCount}
                </span>
              )}
            </button>
            
            <button 
              onClick={() => setIsMobileMenuOpen(true)}
              className="md:hidden text-dark p-2"
              aria-label="Open mobile menu"
            >
              <Menu className="h-6 w-6" />
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile Menu */}
      <MobileMenu isOpen={isMobileMenuOpen} onClose={() => setIsMobileMenuOpen(false)} />
    </header>
  );
}
