import { useState } from "react";
import { useLocation } from "wouter";
import { X, ChevronDown, ChevronRight } from "lucide-react";

interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function MobileMenu({ isOpen, onClose }: MobileMenuProps) {
  const [location, navigate] = useLocation();
  const [isSubmenuOpen, setIsSubmenuOpen] = useState(false);

  const handleNavigation = (path: string) => {
    navigate(path);
    onClose();
  };

  return (
    <div className={`md:hidden ${isOpen ? 'block' : 'hidden'} fixed inset-0 z-50 bg-white`}>
      <div className="p-4 border-b">
        <div className="flex justify-between items-center">
          <h2 className="text-lg font-bold">Menu</h2>
          <button onClick={onClose} aria-label="Close menu">
            <X className="h-6 w-6" />
          </button>
        </div>
      </div>
      
      <nav className="p-4">
        <div 
          className={`block py-2 font-medium ${location === '/' ? 'text-primary' : 'hover:text-primary'} cursor-pointer`}
          onClick={() => handleNavigation("/")}
        >
          Home
        </div>
        
        <button 
          className="flex justify-between items-center w-full py-2 font-medium hover:text-primary"
          onClick={() => setIsSubmenuOpen(!isSubmenuOpen)}
        >
          View the Pouls
          {isSubmenuOpen ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
        </button>
        
        <div className={`pl-4 ${isSubmenuOpen ? 'block' : 'hidden'}`}>
          <div 
            className={`block py-2 ${location === '/male-pouls' ? 'text-primary' : 'hover:text-primary'} cursor-pointer`}
            onClick={() => handleNavigation("/male-pouls")}
          >
            Male Pouls
          </div>
          <div 
            className={`block py-2 ${location === '/champion-pouls' ? 'text-primary font-bold' : 'hover:text-primary'} cursor-pointer flex items-center`}
            onClick={() => handleNavigation("/champion-pouls")}
          >
            Heavyweight Champions (3kg+)
            <span className="ml-2 px-1.5 py-0.5 rounded bg-primary text-white text-xs">NEW</span>
          </div>
          <div 
            className={`block py-2 ${location === '/female-pouls' ? 'text-primary' : 'hover:text-primary'} cursor-pointer`}
            onClick={() => handleNavigation("/female-pouls")}
          >
            Female Pouls
          </div>
          <div 
            className={`block py-2 ${location === '/egg-clusters' ? 'text-primary' : 'hover:text-primary'} cursor-pointer`}
            onClick={() => handleNavigation("/egg-clusters")}
          >
            Egg Clusters
          </div>
          <div 
            className={`block py-2 ${location === '/village-hens' ? 'text-primary' : 'hover:text-primary'} cursor-pointer`}
            onClick={() => handleNavigation("/village-hens")}
          >
            Village Hens
          </div>
          <div 
            className={`block py-2 ${location === '/chicks' ? 'text-primary' : 'hover:text-primary'} cursor-pointer`}
            onClick={() => handleNavigation("/chicks")}
          >
            Baby Pouls (Chicks)
          </div>
        </div>
        
        <div 
          className={`block py-2 font-medium ${location === '/contact' ? 'text-primary' : 'hover:text-primary'} cursor-pointer`}
          onClick={() => handleNavigation("/contact")}
        >
          Contact Us
        </div>
        
        <div 
          className={`block py-2 font-medium ${location === '/help' ? 'text-primary' : 'hover:text-primary'} cursor-pointer`}
          onClick={() => handleNavigation("/help")}
        >
          Help
        </div>
      </nav>
    </div>
  );
}
