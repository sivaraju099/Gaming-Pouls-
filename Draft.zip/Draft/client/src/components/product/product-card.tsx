import { Button } from "@/components/ui/button";
import { Play } from "lucide-react";
import { useCart } from "@/components/cart/cart-provider";
import { formatCurrency } from "@/lib/utils";

export interface ProductCardProps {
  id: string;
  name: string;
  price: number;
  image: string;
  description: string;
  badges?: string[];
  tags?: { label: string; value: string }[];
  hasVideo?: boolean;
  onVideoClick?: () => void;
  variant?: 'default' | 'centered';
}

export default function ProductCard({
  id,
  name,
  price,
  image,
  description,
  badges = [],
  tags = [],
  hasVideo = false,
  onVideoClick,
  variant = 'default'
}: ProductCardProps) {
  const { addItem } = useCart();
  
  const handleAddToCart = () => {
    addItem({
      id,
      name,
      price,
      image
    });
  };
  
  if (variant === 'centered') {
    return (
      <div className="bg-white rounded-lg overflow-hidden shadow-sm product-card">
        <div className="relative">
          <img 
            src={image} 
            alt={name} 
            className="w-full h-60 object-cover" 
          />
          {badges.map((badge, index) => (
            <span 
              key={index}
              className="absolute top-2 right-2 bg-primary text-white text-xs font-bold px-2 py-1 rounded"
            >
              {badge}
            </span>
          ))}
        </div>
        <div className="p-4 text-center">
          <h3 className="font-bold text-lg mb-2">{name}</h3>
          <p className="text-dark-accent text-sm mb-4">{description}</p>
          <div className="text-2xl font-bold text-primary mb-4">{formatCurrency(price)}</div>
          <Button 
            className="w-full"
            onClick={handleAddToCart}
          >
            Add to Cart
          </Button>
        </div>
      </div>
    );
  }
  
  return (
    <div className="bg-white rounded-lg overflow-hidden shadow-sm product-card">
      <div className="relative">
        <img 
          src={image} 
          alt={name} 
          className="w-full h-60 object-cover" 
        />
        {badges.map((badge, index) => (
          <span 
            key={index}
            className="absolute top-2 right-2 bg-primary text-white text-xs font-bold px-2 py-1 rounded"
          >
            {badge}
          </span>
        ))}
      </div>
      <div className="p-4">
        <div className="flex justify-between items-start mb-2">
          <h3 className="font-bold text-lg">{name}</h3>
          <span className="font-semibold text-lg">{formatCurrency(price)}</span>
        </div>
        
        {tags.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-3">
            {tags.map((tag, index) => (
              <span 
                key={index}
                className="bg-gray-100 text-dark-accent text-xs px-2 py-1 rounded"
              >
                {tag.label}: {tag.value}
              </span>
            ))}
          </div>
        )}
        
        <p className="text-dark-accent text-sm mb-4">{description}</p>
        
        <div className="flex items-center justify-between">
          {hasVideo && (
            <button 
              className="text-secondary font-medium flex items-center text-sm"
              onClick={onVideoClick}
            >
              <Play className="h-4 w-4 mr-1" /> Watch Fight
            </button>
          )}
          {!hasVideo && <div />}
          
          <Button 
            onClick={handleAddToCart}
          >
            Add to Cart
          </Button>
        </div>
      </div>
    </div>
  );
}
