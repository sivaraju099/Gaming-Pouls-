import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface QuantitySelectorProps {
  quantity: number;
  onQuantityChange: (quantity: number) => void;
  min?: number;
  max?: number;
  label?: string;
}

export default function QuantitySelector({
  quantity,
  onQuantityChange,
  min = 1,
  max = 100,
  label = "Quantity"
}: QuantitySelectorProps) {
  const handleDecrement = () => {
    if (quantity > min) {
      onQuantityChange(quantity - 1);
    }
  };

  const handleIncrement = () => {
    if (quantity < max) {
      onQuantityChange(quantity + 1);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = parseInt(e.target.value);
    if (!isNaN(newValue) && newValue >= min && newValue <= max) {
      onQuantityChange(newValue);
    }
  };

  return (
    <div>
      <label className="block font-medium mb-2">{label}:</label>
      <div className="flex items-center">
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={handleDecrement}
          disabled={quantity <= min}
          className="px-3 rounded-r-none"
        >
          -
        </Button>
        <Input
          type="number"
          min={min}
          max={max}
          value={quantity}
          onChange={handleInputChange}
          className="w-20 rounded-none text-center [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
        />
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={handleIncrement}
          disabled={quantity >= max}
          className="px-3 rounded-l-none"
        >
          +
        </Button>
      </div>
    </div>
  );
}
