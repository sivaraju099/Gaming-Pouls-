import { useCart, CartItem } from "./cart-provider";
import { X, ShoppingCart, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { formatCurrency } from "@/lib/utils";

export default function CartDrawer() {
  const { 
    items, 
    isCartOpen, 
    updateQuantity, 
    removeItem, 
    closeCart 
  } = useCart();
  
  const subtotal = items.reduce((total, item) => 
    total + (item.price * item.quantity), 0
  );

  return (
    <div 
      className={`fixed top-0 right-0 h-full w-full md:w-96 bg-white shadow-lg transform ${
        isCartOpen ? 'translate-x-0' : 'translate-x-full'
      } transition-transform duration-300 z-50`}
    >
      <div className="flex flex-col h-full">
        <div className="p-4 bg-primary text-white flex justify-between items-center">
          <h3 className="font-bold text-lg">Your Cart</h3>
          <button
            onClick={closeCart}
            className="text-white"
            aria-label="Close cart"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        
        <div className="flex-grow overflow-y-auto p-4">
          {items.length === 0 ? (
            <div className="py-8 text-center">
              <ShoppingCart className="h-12 w-12 text-gray-300 mx-auto mb-4" />
              <p className="text-dark-accent">Your cart is empty</p>
              <p className="text-sm text-gray-500 mt-2">Add items to get started</p>
            </div>
          ) : (
            <div className="space-y-4">
              {items.map((item) => (
                <CartItemRow 
                  key={item.id} 
                  item={item} 
                  updateQuantity={updateQuantity}
                  removeItem={removeItem}
                />
              ))}
            </div>
          )}
        </div>
        
        <div className="border-t p-4 bg-background">
          <div className="flex justify-between mb-4">
            <span className="font-medium">Subtotal:</span>
            <span className="font-bold">{formatCurrency(subtotal)}</span>
          </div>
          <Button 
            className="w-full" 
            disabled={items.length === 0}
            onClick={() => alert("Proceeding to checkout! This would typically redirect to a payment page.")}
          >
            Proceed to Checkout
          </Button>
        </div>
      </div>
    </div>
  );
}

interface CartItemRowProps {
  item: CartItem;
  updateQuantity: (id: string, quantity: number) => void;
  removeItem: (id: string) => void;
}

function CartItemRow({ item, updateQuantity, removeItem }: CartItemRowProps) {
  return (
    <div className="flex py-4 border-b">
      <div className="w-20 h-20 rounded overflow-hidden mr-4">
        <img 
          src={item.image} 
          alt={item.name} 
          className="w-full h-full object-cover"
        />
      </div>
      <div className="flex-grow">
        <h4 className="font-medium">{item.name}</h4>
        <div className="flex justify-between items-center mt-2">
          <div className="flex items-center">
            <button 
              className="border px-2 rounded-l"
              onClick={() => updateQuantity(item.id, item.quantity - 1)}
              disabled={item.quantity <= 1}
              aria-label="Decrease quantity"
            >
              -
            </button>
            <span className="px-2 border-t border-b">
              {item.quantity}
            </span>
            <button 
              className="border px-2 rounded-r"
              onClick={() => updateQuantity(item.id, item.quantity + 1)}
              aria-label="Increase quantity"
            >
              +
            </button>
          </div>
          <div className="font-medium">{formatCurrency(item.price * item.quantity)}</div>
        </div>
      </div>
      <button 
        className="ml-2 text-gray-400 hover:text-destructive"
        onClick={() => removeItem(item.id)}
        aria-label="Remove item"
      >
        <Trash2 className="h-5 w-5" />
      </button>
    </div>
  );
}
