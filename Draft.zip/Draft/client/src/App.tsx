import { Switch, Route, useLocation } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Toaster } from "@/components/ui/toaster";
import { CartProvider } from "./components/cart/cart-provider";
import NotFound from "@/pages/not-found";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import Home from "@/pages/home";
import MalePouls from "@/pages/male-pouls";
import FemalePouls from "@/pages/female-pouls";
import EggClusters from "@/pages/egg-clusters";
import VillageHens from "@/pages/village-hens";
import Chicks from "@/pages/chicks";
import Contact from "@/pages/contact";
import Help from "@/pages/help";
import CartDrawer from "@/components/cart/cart-drawer";
import AdminLogin from "@/pages/admin/login";
import AdminDashboard from "@/pages/admin/dashboard-fixed";

// Import all pages directly for now to avoid loading issues
import { Suspense } from "react";
import HenDeployment from "./pages/hen-deployment";
import ChampionPouls from "./pages/champion-pouls";

function Router() {
  const [location] = useLocation();
  const isAdminRoute = location.startsWith("/admin");

  return (
    <Suspense fallback={<div className="flex justify-center items-center min-h-screen">Loading...</div>}>
      <Switch>
        {/* Main site routes */}
        <Route path="/" component={Home} />
        <Route path="/male-pouls" component={MalePouls} />
        <Route path="/female-pouls" component={FemalePouls} />
        <Route path="/egg-clusters" component={EggClusters} />
        <Route path="/village-hens" component={VillageHens} />
        <Route path="/chicks" component={Chicks} />
        <Route path="/champion-pouls" component={ChampionPouls} />
        <Route path="/contact" component={Contact} />
        <Route path="/help" component={Help} />
        <Route path="/hen-deployment" component={HenDeployment} />
        
        {/* Admin routes */}
        <Route path="/admin/login" component={AdminLogin} />
        <Route path="/admin/dashboard" component={AdminDashboard} />
        
        {/* 404 route */}
        <Route component={NotFound} />
      </Switch>
    </Suspense>
  );
}

function App() {
  const [location] = useLocation();
  const isAdminRoute = location.startsWith("/admin");

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <CartProvider>
          {!isAdminRoute ? (
            <div className="flex flex-col min-h-screen">
              <Header />
              <main className="flex-grow">
                <Router />
              </main>
              <Footer />
              <CartDrawer />
            </div>
          ) : (
            <Router />
          )}
          <Toaster />
        </CartProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
