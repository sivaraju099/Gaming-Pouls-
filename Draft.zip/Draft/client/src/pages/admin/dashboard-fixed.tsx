import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Helmet } from "react-helmet";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import {
  Users,
  ShoppingBag,
  LogOut,
  Upload,
  Grid,
  LayoutDashboard,
  Settings,
  Plus,
  Edit,
  Trash2
} from "lucide-react";

// Admin Dashboard Page
export default function AdminDashboard() {
  const [_, navigate] = useLocation();
  const { toast } = useToast();
  const [activeSection, setActiveSection] = useState("overview");
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  // Data states
  const [products, setProducts] = useState([
    { id: "1", name: "Champion Red Warrior", category: "Male Pouls", price: 12500, stock: 3 },
    { id: "2", name: "Elite Breeding Hen", category: "Female Pouls", price: 8500, stock: 5 },
    { id: "3", name: "Premium Chicks Package", category: "Chicks", price: 3200, stock: 10 },
    { id: "4", name: "Hatching Eggs Cluster", category: "Egg Clusters", price: 2500, stock: 15 },
  ]);
  
  const [deployments, setDeployments] = useState([
    {
      id: "d1",
      customerName: "Rajesh Kumar",
      henName: "Thunder Striker",
      description: "2-year-old champion male with exceptional fighting skills",
      price: 15000,
      status: "pending",
      date: "2023-11-15"
    },
    {
      id: "d2",
      customerName: "Suresh Patel",
      henName: "Golden Princess",
      description: "Premium breeding female with strong genetic line",
      price: 9500,
      status: "approved",
      date: "2023-11-12"
    },
    {
      id: "d3",
      customerName: "Amit Singh",
      henName: "Storm Chaser",
      description: "Young male poul with training potential",
      price: 7800,
      status: "rejected",
      date: "2023-11-10"
    },
  ]);
  
  const [customers, setCustomers] = useState([
    { id: "c1", name: "Rajesh Kumar", email: "rajesh@example.com", orders: 3, totalSpent: 45000 },
    { id: "c2", name: "Suresh Patel", email: "suresh@example.com", orders: 2, totalSpent: 28000 },
    { id: "c3", name: "Amit Singh", email: "amit@example.com", orders: 1, totalSpent: 15000 },
  ]);
  
  // Form states
  const [showNewDeploymentForm, setShowNewDeploymentForm] = useState(false);
  const [newDeployment, setNewDeployment] = useState({
    customerName: "",
    henName: "",
    description: "",
    price: 0,
  });
  
  const [showNewProductForm, setShowNewProductForm] = useState(false);
  const [newProduct, setNewProduct] = useState({
    name: "",
    category: "Male Pouls",
    price: 0,
    stock: 0
  });
  
  // Authentication check
  useEffect(() => {
    // Check if user is authenticated as admin
    const isAdmin = localStorage.getItem("adminAuthenticated") === "true";
    
    if (!isAdmin) {
      toast({
        title: "Unauthorized",
        description: "Please login to access the admin dashboard",
        variant: "destructive",
      });
      navigate("/admin/login");
    }
  }, [navigate, toast]);
  
  // Form handlers
  const handleNewProductSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const product = {
      id: String(products.length + 1),
      ...newProduct
    };
    
    setProducts([...products, product]);
    setShowNewProductForm(false);
    setNewProduct({
      name: "",
      category: "Male Pouls",
      price: 0,
      stock: 0
    });
    
    toast({
      title: "Product Added",
      description: "New product has been added successfully",
    });
  };
  
  const handleNewDeploymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const deployment = {
      id: `d${deployments.length + 1}`,
      ...newDeployment,
      status: "pending",
      date: new Date().toISOString().split('T')[0]
    };
    
    setDeployments([deployment, ...deployments]);
    setShowNewDeploymentForm(false);
    setNewDeployment({
      customerName: "",
      henName: "",
      description: "",
      price: 0,
    });
    
    toast({
      title: "Deployment Added",
      description: "New hen deployment has been added successfully",
    });
  };
  
  const updateDeploymentStatus = (id: string, status: string) => {
    setDeployments(
      deployments.map(d => 
        d.id === id ? { ...d, status } : d
      )
    );
    
    toast({
      title: "Status Updated",
      description: `Deployment has been ${status}`,
    });
  };
  
  const deleteProduct = (id: string) => {
    setProducts(products.filter(p => p.id !== id));
    toast({
      title: "Product Deleted",
      description: "Product has been deleted successfully",
    });
  };
  
  const handleLogout = () => {
    localStorage.removeItem("adminAuthenticated");
    localStorage.removeItem("adminEmail");
    
    toast({
      title: "Logged out",
      description: "You have been logged out successfully",
    });
    
    navigate("/admin/login");
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Admin Header */}
      <header className="bg-white border-b py-4 px-6 flex items-center justify-between sticky top-0 z-30">
        <div className="flex items-center">
          <button 
            className="md:hidden mr-4"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            <Grid className="h-5 w-5" />
          </button>
          <h1 className="text-xl font-bold">Gaming Pouls Admin</h1>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="text-sm text-gray-600">
            <span className="font-semibold">Logged in as:</span> {localStorage.getItem("adminEmail")}
          </div>
          <Button variant="ghost" size="sm" onClick={handleLogout}>
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>
      </header>

      <div className="flex flex-1">
        {/* Sidebar */}
        <aside className={`w-64 bg-white h-screen border-r fixed left-0 top-16 shadow-sm transition-transform duration-300 z-40 ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}`}>
          <div className="p-4">
            <nav className="space-y-1 mt-6">
              <button 
                onClick={() => setActiveSection("overview")} 
                className={`flex items-center gap-3 px-4 py-3 w-full text-left ${activeSection === "overview" ? 'bg-primary/10 text-primary font-medium border-r-4 border-primary' : 'text-gray-700 hover:bg-gray-100'} transition-colors`}
              >
                <LayoutDashboard className="h-5 w-5" />
                Dashboard
              </button>
              <button
                onClick={() => setActiveSection("products")}
                className={`flex items-center gap-3 px-4 py-3 w-full text-left ${activeSection === "products" ? 'bg-primary/10 text-primary font-medium border-r-4 border-primary' : 'text-gray-700 hover:bg-gray-100'} transition-colors`}
              >
                <ShoppingBag className="h-5 w-5" />
                Products
              </button>
              <button
                onClick={() => setActiveSection("deployments")}
                className={`flex items-center gap-3 px-4 py-3 w-full text-left ${activeSection === "deployments" ? 'bg-primary/10 text-primary font-medium border-r-4 border-primary' : 'text-gray-700 hover:bg-gray-100'} transition-colors`}
              >
                <Upload className="h-5 w-5" />
                Hen Deployments
              </button>
              <button
                onClick={() => setActiveSection("customers")}
                className={`flex items-center gap-3 px-4 py-3 w-full text-left ${activeSection === "customers" ? 'bg-primary/10 text-primary font-medium border-r-4 border-primary' : 'text-gray-700 hover:bg-gray-100'} transition-colors`}
              >
                <Users className="h-5 w-5" />
                Customers
              </button>
              <button
                onClick={() => setActiveSection("settings")}
                className={`flex items-center gap-3 px-4 py-3 w-full text-left ${activeSection === "settings" ? 'bg-primary/10 text-primary font-medium border-r-4 border-primary' : 'text-gray-700 hover:bg-gray-100'} transition-colors`}
              >
                <Settings className="h-5 w-5" />
                Settings
              </button>
            </nav>
          </div>
        </aside>

        {/* Mobile overlay for closing sidebar */}
        {isMobileMenuOpen && (
          <div 
            className="md:hidden fixed inset-0 bg-black/20 z-30 mt-16"
            onClick={() => setIsMobileMenuOpen(false)}
          />
        )}

        {/* Main Content */}
        <main className="p-6 ml-0 md:ml-64 flex-1 mt-16">
          <Helmet>
            <title>Admin Dashboard | Gaming Pouls</title>
          </Helmet>

          {/* Overview Section */}
          {activeSection === "overview" && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold">Dashboard Overview</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white p-6 rounded-lg shadow-sm">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-gray-500 text-sm">Total Products</p>
                      <h3 className="text-2xl font-bold mt-1">{products.length}</h3>
                    </div>
                    <div className="bg-primary/10 p-3 rounded-full">
                      <ShoppingBag className="h-6 w-6 text-primary" />
                    </div>
                  </div>
                  <div className="mt-4">
                    <Button variant="ghost" size="sm" className="text-primary px-0" onClick={() => setActiveSection("products")}>
                      View all products
                    </Button>
                  </div>
                </div>
                
                <div className="bg-white p-6 rounded-lg shadow-sm">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-gray-500 text-sm">Deployment Requests</p>
                      <h3 className="text-2xl font-bold mt-1">{deployments.length}</h3>
                    </div>
                    <div className="bg-primary/10 p-3 rounded-full">
                      <Upload className="h-6 w-6 text-primary" />
                    </div>
                  </div>
                  <div className="mt-4">
                    <Button variant="ghost" size="sm" className="text-primary px-0" onClick={() => setActiveSection("deployments")}>
                      View all deployments
                    </Button>
                  </div>
                </div>
                
                <div className="bg-white p-6 rounded-lg shadow-sm">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-gray-500 text-sm">Total Customers</p>
                      <h3 className="text-2xl font-bold mt-1">{customers.length}</h3>
                    </div>
                    <div className="bg-primary/10 p-3 rounded-full">
                      <Users className="h-6 w-6 text-primary" />
                    </div>
                  </div>
                  <div className="mt-4">
                    <Button variant="ghost" size="sm" className="text-primary px-0" onClick={() => setActiveSection("customers")}>
                      View all customers
                    </Button>
                  </div>
                </div>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-sm mt-6">
                <h3 className="font-bold text-lg mb-4">Recent Deployment Requests</h3>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="py-3 text-left">Customer</th>
                        <th className="py-3 text-left">Hen Name</th>
                        <th className="py-3 text-left">Price</th>
                        <th className="py-3 text-left">Status</th>
                        <th className="py-3 text-left">Date</th>
                      </tr>
                    </thead>
                    <tbody>
                      {deployments.slice(0, 3).map((deployment) => (
                        <tr key={deployment.id} className="border-b">
                          <td className="py-3">{deployment.customerName}</td>
                          <td className="py-3">{deployment.henName}</td>
                          <td className="py-3">₹{deployment.price.toLocaleString()}</td>
                          <td className="py-3">
                            <span className={`px-2 py-1 rounded-full text-xs ${
                              deployment.status === "approved" ? "bg-green-100 text-green-800" :
                              deployment.status === "rejected" ? "bg-red-100 text-red-800" :
                              "bg-yellow-100 text-yellow-800"
                            }`}>
                              {deployment.status}
                            </span>
                          </td>
                          <td className="py-3">{deployment.date}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* Products Section */}
          {activeSection === "products" && (
            <div className="space-y-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold">Products Management</h2>
                <Button onClick={() => setShowNewProductForm(true)}>
                  <Plus className="h-4 w-4 mr-2" /> Add Product
                </Button>
              </div>
              
              {showNewProductForm && (
                <div className="bg-white p-6 rounded-lg shadow-sm mb-6">
                  <h3 className="font-bold text-lg mb-4">Add New Product</h3>
                  <form onSubmit={handleNewProductSubmit} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium mb-1">Product Name</label>
                        <input
                          type="text"
                          className="w-full p-2 border rounded-md"
                          required
                          value={newProduct.name}
                          onChange={(e) => setNewProduct({...newProduct, name: e.target.value})}
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-1">Category</label>
                        <select
                          className="w-full p-2 border rounded-md"
                          value={newProduct.category}
                          onChange={(e) => setNewProduct({...newProduct, category: e.target.value})}
                        >
                          <option value="Male Pouls">Male Pouls</option>
                          <option value="Female Pouls">Female Pouls</option>
                          <option value="Egg Clusters">Egg Clusters</option>
                          <option value="Village Hens">Village Hens</option>
                          <option value="Chicks">Chicks</option>
                          <option value="Champion Pouls">Champion Pouls</option>
                        </select>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium mb-1">Price (₹)</label>
                        <input
                          type="number"
                          className="w-full p-2 border rounded-md"
                          required
                          min="0"
                          value={newProduct.price}
                          onChange={(e) => setNewProduct({...newProduct, price: Number(e.target.value)})}
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-1">Stock</label>
                        <input
                          type="number"
                          className="w-full p-2 border rounded-md"
                          required
                          min="0"
                          value={newProduct.stock}
                          onChange={(e) => setNewProduct({...newProduct, stock: Number(e.target.value)})}
                        />
                      </div>
                    </div>
                    
                    <div className="flex justify-end space-x-2">
                      <Button type="button" variant="outline" onClick={() => setShowNewProductForm(false)}>
                        Cancel
                      </Button>
                      <Button type="submit">
                        Add Product
                      </Button>
                    </div>
                  </form>
                </div>
              )}
              
              <div className="bg-white rounded-lg shadow-sm overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-gray-50 border-b">
                        <th className="py-3 px-4 text-left">ID</th>
                        <th className="py-3 px-4 text-left">Name</th>
                        <th className="py-3 px-4 text-left">Category</th>
                        <th className="py-3 px-4 text-left">Price</th>
                        <th className="py-3 px-4 text-left">Stock</th>
                        <th className="py-3 px-4 text-left">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {products.map((product) => (
                        <tr key={product.id} className="border-b">
                          <td className="py-3 px-4">{product.id}</td>
                          <td className="py-3 px-4 font-medium">{product.name}</td>
                          <td className="py-3 px-4">{product.category}</td>
                          <td className="py-3 px-4">₹{product.price.toLocaleString()}</td>
                          <td className="py-3 px-4">{product.stock}</td>
                          <td className="py-3 px-4">
                            <div className="flex space-x-2">
                              <Button variant="ghost" size="sm">
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                className="text-red-500"
                                onClick={() => deleteProduct(product.id)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* Deployments Section */}
          {activeSection === "deployments" && (
            <div className="space-y-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold">Hen Deployments</h2>
                <Button onClick={() => setShowNewDeploymentForm(true)}>
                  <Plus className="h-4 w-4 mr-2" /> New Deployment
                </Button>
              </div>
              
              {showNewDeploymentForm && (
                <div className="bg-white p-6 rounded-lg shadow-sm mb-6">
                  <h3 className="font-bold text-lg mb-4">Add New Hen Deployment</h3>
                  <form onSubmit={handleNewDeploymentSubmit} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium mb-1">Customer Name</label>
                        <input
                          type="text"
                          className="w-full p-2 border rounded-md"
                          required
                          value={newDeployment.customerName}
                          onChange={(e) => setNewDeployment({...newDeployment, customerName: e.target.value})}
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-1">Hen Name</label>
                        <input
                          type="text"
                          className="w-full p-2 border rounded-md"
                          required
                          value={newDeployment.henName}
                          onChange={(e) => setNewDeployment({...newDeployment, henName: e.target.value})}
                        />
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium mb-1">Description</label>
                      <textarea
                        className="w-full p-2 border rounded-md"
                        rows={3}
                        required
                        value={newDeployment.description}
                        onChange={(e) => setNewDeployment({...newDeployment, description: e.target.value})}
                      ></textarea>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium mb-1">Price (₹)</label>
                      <input
                        type="number"
                        className="w-full p-2 border rounded-md"
                        required
                        min="0"
                        value={newDeployment.price}
                        onChange={(e) => setNewDeployment({...newDeployment, price: Number(e.target.value)})}
                      />
                    </div>
                    
                    <div className="flex justify-end space-x-2">
                      <Button type="button" variant="outline" onClick={() => setShowNewDeploymentForm(false)}>
                        Cancel
                      </Button>
                      <Button type="submit">
                        Submit Deployment
                      </Button>
                    </div>
                  </form>
                </div>
              )}
              
              <div className="bg-white rounded-lg shadow-sm overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-gray-50 border-b">
                        <th className="py-3 px-4 text-left">Customer</th>
                        <th className="py-3 px-4 text-left">Hen Name</th>
                        <th className="py-3 px-4 text-left">Description</th>
                        <th className="py-3 px-4 text-left">Price</th>
                        <th className="py-3 px-4 text-left">Status</th>
                        <th className="py-3 px-4 text-left">Date</th>
                        <th className="py-3 px-4 text-left">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {deployments.map((deployment) => (
                        <tr key={deployment.id} className="border-b">
                          <td className="py-3 px-4">{deployment.customerName}</td>
                          <td className="py-3 px-4 font-medium">{deployment.henName}</td>
                          <td className="py-3 px-4 max-w-xs truncate">{deployment.description}</td>
                          <td className="py-3 px-4">₹{deployment.price.toLocaleString()}</td>
                          <td className="py-3 px-4">
                            <span className={`px-2 py-1 rounded-full text-xs ${
                              deployment.status === "approved" ? "bg-green-100 text-green-800" :
                              deployment.status === "rejected" ? "bg-red-100 text-red-800" :
                              "bg-yellow-100 text-yellow-800"
                            }`}>
                              {deployment.status}
                            </span>
                          </td>
                          <td className="py-3 px-4">{deployment.date}</td>
                          <td className="py-3 px-4">
                            {deployment.status === "pending" && (
                              <div className="flex space-x-2">
                                <Button 
                                  variant="outline" 
                                  size="sm" 
                                  className="text-green-600 border-green-600 hover:bg-green-50"
                                  onClick={() => updateDeploymentStatus(deployment.id, "approved")}
                                >
                                  Approve
                                </Button>
                                <Button 
                                  variant="outline" 
                                  size="sm" 
                                  className="text-red-600 border-red-600 hover:bg-red-50"
                                  onClick={() => updateDeploymentStatus(deployment.id, "rejected")}
                                >
                                  Reject
                                </Button>
                              </div>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
          
          {/* Customers Section */}
          {activeSection === "customers" && (
            <div className="space-y-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold">Customer Management</h2>
                <Button>
                  <Plus className="h-4 w-4 mr-2" /> Add Customer
                </Button>
              </div>
              
              <div className="bg-white rounded-lg shadow-sm overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-gray-50 border-b">
                        <th className="py-3 px-4 text-left">ID</th>
                        <th className="py-3 px-4 text-left">Name</th>
                        <th className="py-3 px-4 text-left">Email</th>
                        <th className="py-3 px-4 text-left">Orders</th>
                        <th className="py-3 px-4 text-left">Total Spent</th>
                        <th className="py-3 px-4 text-left">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {customers.map((customer) => (
                        <tr key={customer.id} className="border-b">
                          <td className="py-3 px-4">{customer.id}</td>
                          <td className="py-3 px-4 font-medium">{customer.name}</td>
                          <td className="py-3 px-4">{customer.email}</td>
                          <td className="py-3 px-4">{customer.orders}</td>
                          <td className="py-3 px-4">₹{customer.totalSpent.toLocaleString()}</td>
                          <td className="py-3 px-4">
                            <div className="flex space-x-2">
                              <Button variant="ghost" size="sm">
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="sm" className="text-red-500">
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
          
          {/* Settings Section */}
          {activeSection === "settings" && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold">Settings</h2>
              
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <h3 className="font-bold text-lg mb-4">Admin Account</h3>
                <form className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Email</label>
                    <input
                      type="email"
                      className="w-full p-2 border rounded-md"
                      value={localStorage.getItem("adminEmail") || ""}
                      disabled
                    />
                    <p className="text-sm text-gray-500 mt-1">Email cannot be changed</p>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium mb-1">Password</label>
                    <input
                      type="password"
                      className="w-full p-2 border rounded-md"
                      placeholder="••••••••"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium mb-1">Confirm Password</label>
                    <input
                      type="password"
                      className="w-full p-2 border rounded-md"
                      placeholder="••••••••"
                    />
                  </div>
                  
                  <div>
                    <Button>Update Password</Button>
                  </div>
                </form>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <h3 className="font-bold text-lg mb-4">Database Connection</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Database Status</label>
                    <div className="flex items-center">
                      <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
                      <span>Connected</span>
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium mb-1">Database URL</label>
                    <input
                      type="text"
                      className="w-full p-2 border rounded-md"
                      value="**********************"
                      disabled
                    />
                    <p className="text-sm text-gray-500 mt-1">Database connection string is hidden for security</p>
                  </div>
                  
                  <div>
                    <Button>Test Database Connection</Button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}