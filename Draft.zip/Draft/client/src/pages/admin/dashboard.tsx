import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Helmet } from "react-helmet";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import {
  Users,
  ShoppingBag,
  LogOut,
  Upload,
  Grid,
  LayoutDashboard,
  Settings,
  ChevronDown,
  Plus,
  Edit,
  Trash2
} from "lucide-react";

// Admin layout component
function AdminLayout({ children, activeTab, setActiveTab }: { 
  children: React.ReactNode;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}) {
  const [_, navigate] = useLocation();
  const { toast } = useToast();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    // Check if user is authenticated as admin
    const isAdmin = localStorage.getItem("adminAuthenticated") === "true";
    
    if (!isAdmin) {
      toast({
        title: "Unauthorized",
        description: "Please login to access the admin dashboard",
        variant: "destructive",
      });
      navigate("/admin/login");
    }
  }, [navigate, toast]);

  const handleLogout = () => {
    localStorage.removeItem("adminAuthenticated");
    localStorage.removeItem("adminEmail");
    
    toast({
      title: "Logged out",
      description: "You have been logged out successfully",
    });
    
    navigate("/admin/login");
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Admin Header */}
      <header className="admin-header">
        <div className="flex items-center">
          <button 
            className="md:hidden mr-4"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            <Grid className="h-5 w-5" />
          </button>
          <h1 className="text-xl font-bold">Gaming Pouls Admin</h1>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="text-sm text-gray-600">
            <span className="font-semibold">Logged in as:</span> {localStorage.getItem("adminEmail")}
          </div>
          <Button variant="ghost" size="sm" onClick={handleLogout}>
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>
      </header>

      <div className="flex flex-1">
        {/* Sidebar */}
        <aside className={`admin-sidebar ${isMobileMenuOpen ? 'open' : ''}`}>
          <div className="p-4">
            <nav className="space-y-1 mt-6">
              <button 
                onClick={() => setActiveTab("overview")} 
                className={`admin-menu-item w-full text-left ${activeTab === "overview" ? 'active' : ''}`}
              >
                <LayoutDashboard className="h-5 w-5" />
                Dashboard
              </button>
              <button
                onClick={() => setActiveTab("products")}
                className={`admin-menu-item w-full text-left ${activeTab === "products" ? 'active' : ''}`}
              >
                <ShoppingBag className="h-5 w-5" />
                Products
              </button>
              <button
                onClick={() => setActiveTab("deployments")}
                className={`admin-menu-item w-full text-left ${activeTab === "deployments" ? 'active' : ''}`}
              >
                <Upload className="h-5 w-5" />
                Hen Deployments
              </button>
              <button
                onClick={() => setActiveTab("customers")}
                className={`admin-menu-item w-full text-left ${activeTab === "customers" ? 'active' : ''}`}
              >
                <Users className="h-5 w-5" />
                Customers
              </button>
              <button
                onClick={() => setActiveTab("settings")}
                className={`admin-menu-item w-full text-left ${activeTab === "settings" ? 'active' : ''}`}
              >
                <Settings className="h-5 w-5" />
                Settings
              </button>
            </nav>
          </div>
        </aside>

        {/* Mobile overlay for closing sidebar */}
        {isMobileMenuOpen && (
          <div 
            className="md:hidden fixed inset-0 bg-black/20 z-30"
            onClick={() => setIsMobileMenuOpen(false)}
          />
        )}

        {/* Main Content */}
        <main className="admin-content">
          {children}
        </main>
      </div>
    </div>
  );
}

// Mocked product data for demonstration
const mockProducts = [
  { 
    id: "1", 
    name: "Champion Red Warrior", 
    category: "Male Pouls", 
    price: 12500, 
    stock: 3 
  },
  { 
    id: "2", 
    name: "Elite Breeding Hen", 
    category: "Female Pouls", 
    price: 8500, 
    stock: 5 
  },
  { 
    id: "3", 
    name: "Premium Chicks Package", 
    category: "Chicks", 
    price: 3200, 
    stock: 10 
  },
  { 
    id: "4", 
    name: "Hatching Eggs Cluster", 
    category: "Egg Clusters", 
    price: 2500, 
    stock: 15 
  },
];

// Mocked deployment requests data for demonstration
const mockDeployments = [
  {
    id: "d1",
    customerName: "Rajesh Kumar",
    henName: "Thunder Striker",
    description: "2-year-old champion male with exceptional fighting skills",
    price: 15000,
    status: "pending",
    date: "2023-11-15"
  },
  {
    id: "d2",
    customerName: "Suresh Patel",
    henName: "Golden Princess",
    description: "Premium breeding female with strong genetic line",
    price: 9500,
    status: "approved",
    date: "2023-11-12"
  },
  {
    id: "d3",
    customerName: "Amit Singh",
    henName: "Storm Chaser",
    description: "Young male poul with training potential",
    price: 7800,
    status: "rejected",
    date: "2023-11-10"
  },
];

export default function AdminDashboard() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("overview");
  const [products, setProducts] = useState(mockProducts);
  const [deployments, setDeployments] = useState(mockDeployments);
  const [customers, setCustomers] = useState([
    { id: "c1", name: "Rajesh Kumar", email: "rajesh@example.com", orders: 3, totalSpent: 45000 },
    { id: "c2", name: "Suresh Patel", email: "suresh@example.com", orders: 2, totalSpent: 28000 },
    { id: "c3", name: "Amit Singh", email: "amit@example.com", orders: 1, totalSpent: 15000 },
  ]);
  
  // For new deployment form
  const [showNewDeploymentForm, setShowNewDeploymentForm] = useState(false);
  const [newDeployment, setNewDeployment] = useState({
    customerName: "",
    henName: "",
    description: "",
    price: 0,
  });
  
  // For new product form
  const [showNewProductForm, setShowNewProductForm] = useState(false);
  const [newProduct, setNewProduct] = useState({
    name: "",
    category: "Male Pouls",
    price: 0,
    stock: 0,
    description: ""
  });
  
  const handleNewProductSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const product = {
      id: `p${products.length + 1}`,
      ...newProduct
    };
    
    setProducts([...products, product]);
    setShowNewProductForm(false);
    setNewProduct({
      name: "",
      category: "Male Pouls",
      price: 0,
      stock: 0,
      description: ""
    });
    
    toast({
      title: "Product Added",
      description: "New product has been added successfully",
    });
  };
  
  const handleNewDeploymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const deployment = {
      id: `d${deployments.length + 1}`,
      ...newDeployment,
      status: "pending",
      date: new Date().toISOString().split('T')[0]
    };
    
    setDeployments([deployment, ...deployments]);
    setShowNewDeploymentForm(false);
    setNewDeployment({
      customerName: "",
      henName: "",
      description: "",
      price: 0,
    });
    
    toast({
      title: "Deployment Added",
      description: "New hen deployment has been added successfully",
    });
  };
  
  const updateDeploymentStatus = (id: string, status: string) => {
    setDeployments(
      deployments.map(d => 
        d.id === id ? { ...d, status } : d
      )
    );
    
    toast({
      title: "Status Updated",
      description: `Deployment has been ${status}`,
    });
  };
  
  const deleteProduct = (id: string) => {
    setProducts(products.filter(p => p.id !== id));
    toast({
      title: "Product Deleted",
      description: "Product has been deleted successfully",
    });
  };

  return (
    <AdminLayout activeTab={activeTab} setActiveTab={setActiveTab}>
      <Helmet>
        <title>Admin Dashboard | Gaming Pouls</title>
      </Helmet>

      <div>
        {/* Custom tab system that completely replaces the original Tabs component to avoid any issues */}
        <div className="w-full">{
        activeTab === "overview" && (
          
          <TabsContent value="overview" className="space-y-6">
            <h2 className="text-2xl font-bold">Dashboard Overview</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-gray-500 text-sm">Total Products</p>
                    <h3 className="text-2xl font-bold mt-1">{products.length}</h3>
                  </div>
                  <div className="bg-primary/10 p-3 rounded-full">
                    <ShoppingBag className="h-6 w-6 text-primary" />
                  </div>
                </div>
                <div className="mt-4">
                  <Button variant="ghost" size="sm" className="text-primary px-0">
                    View all products
                  </Button>
                </div>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-gray-500 text-sm">Deployment Requests</p>
                    <h3 className="text-2xl font-bold mt-1">{deployments.length}</h3>
                  </div>
                  <div className="bg-primary/10 p-3 rounded-full">
                    <Upload className="h-6 w-6 text-primary" />
                  </div>
                </div>
                <div className="mt-4">
                  <Button variant="ghost" size="sm" className="text-primary px-0">
                    View all deployments
                  </Button>
                </div>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-gray-500 text-sm">Pending Requests</p>
                    <h3 className="text-2xl font-bold mt-1">
                      {deployments.filter(d => d.status === "pending").length}
                    </h3>
                  </div>
                  <div className="bg-orange-100 p-3 rounded-full">
                    <ChevronDown className="h-6 w-6 text-orange-500" />
                  </div>
                </div>
                <div className="mt-4">
                  <Button variant="ghost" size="sm" className="text-primary px-0">
                    Review pending
                  </Button>
                </div>
              </div>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm mt-6">
              <h3 className="font-bold text-lg mb-4">Recent Deployment Requests</h3>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="py-3 text-left">Customer</th>
                      <th className="py-3 text-left">Hen Name</th>
                      <th className="py-3 text-left">Price</th>
                      <th className="py-3 text-left">Status</th>
                      <th className="py-3 text-left">Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {deployments.slice(0, 3).map((deployment) => (
                      <tr key={deployment.id} className="border-b">
                        <td className="py-3">{deployment.customerName}</td>
                        <td className="py-3">{deployment.henName}</td>
                        <td className="py-3">₹{deployment.price.toLocaleString()}</td>
                        <td className="py-3">
                          <span className={`px-2 py-1 rounded-full text-xs ${
                            deployment.status === "approved" ? "bg-green-100 text-green-800" :
                            deployment.status === "rejected" ? "bg-red-100 text-red-800" :
                            "bg-yellow-100 text-yellow-800"
                          }`}>
                            {deployment.status}
                          </span>
                        </td>
                        <td className="py-3">{deployment.date}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="products" className="space-y-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold">Products Management</h2>
              <Button>
                <Plus className="h-4 w-4 mr-2" /> Add Product
              </Button>
            </div>
            
            <div className="bg-white rounded-lg shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="bg-gray-50 border-b">
                      <th className="py-3 px-4 text-left">ID</th>
                      <th className="py-3 px-4 text-left">Name</th>
                      <th className="py-3 px-4 text-left">Category</th>
                      <th className="py-3 px-4 text-left">Price</th>
                      <th className="py-3 px-4 text-left">Stock</th>
                      <th className="py-3 px-4 text-left">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {products.map((product) => (
                      <tr key={product.id} className="border-b">
                        <td className="py-3 px-4">{product.id}</td>
                        <td className="py-3 px-4 font-medium">{product.name}</td>
                        <td className="py-3 px-4">{product.category}</td>
                        <td className="py-3 px-4">₹{product.price.toLocaleString()}</td>
                        <td className="py-3 px-4">{product.stock}</td>
                        <td className="py-3 px-4">
                          <div className="flex space-x-2">
                            <Button variant="ghost" size="sm">
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="sm" className="text-red-500">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="deployments" className="space-y-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold">Hen Deployments</h2>
              <Button onClick={() => setShowNewDeploymentForm(true)}>
                <Plus className="h-4 w-4 mr-2" /> New Deployment
              </Button>
            </div>
            
            {showNewDeploymentForm && (
              <div className="bg-white p-6 rounded-lg shadow-sm mb-6">
                <h3 className="font-bold text-lg mb-4">Add New Hen Deployment</h3>
                <form onSubmit={handleNewDeploymentSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-1">Customer Name</label>
                      <input
                        type="text"
                        className="w-full p-2 border rounded-md"
                        required
                        value={newDeployment.customerName}
                        onChange={(e) => setNewDeployment({...newDeployment, customerName: e.target.value})}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">Hen Name</label>
                      <input
                        type="text"
                        className="w-full p-2 border rounded-md"
                        required
                        value={newDeployment.henName}
                        onChange={(e) => setNewDeployment({...newDeployment, henName: e.target.value})}
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium mb-1">Description</label>
                    <textarea
                      className="w-full p-2 border rounded-md"
                      rows={3}
                      required
                      value={newDeployment.description}
                      onChange={(e) => setNewDeployment({...newDeployment, description: e.target.value})}
                    ></textarea>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium mb-1">Price (₹)</label>
                    <input
                      type="number"
                      className="w-full p-2 border rounded-md"
                      required
                      min="0"
                      value={newDeployment.price}
                      onChange={(e) => setNewDeployment({...newDeployment, price: Number(e.target.value)})}
                    />
                  </div>
                  
                  <div className="flex justify-end space-x-2">
                    <Button type="button" variant="outline" onClick={() => setShowNewDeploymentForm(false)}>
                      Cancel
                    </Button>
                    <Button type="submit">
                      Submit Deployment
                    </Button>
                  </div>
                </form>
              </div>
            )}
            
            <div className="bg-white rounded-lg shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="bg-gray-50 border-b">
                      <th className="py-3 px-4 text-left">Customer</th>
                      <th className="py-3 px-4 text-left">Hen Name</th>
                      <th className="py-3 px-4 text-left">Description</th>
                      <th className="py-3 px-4 text-left">Price</th>
                      <th className="py-3 px-4 text-left">Status</th>
                      <th className="py-3 px-4 text-left">Date</th>
                      <th className="py-3 px-4 text-left">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {deployments.map((deployment) => (
                      <tr key={deployment.id} className="border-b">
                        <td className="py-3 px-4">{deployment.customerName}</td>
                        <td className="py-3 px-4 font-medium">{deployment.henName}</td>
                        <td className="py-3 px-4 max-w-xs truncate">{deployment.description}</td>
                        <td className="py-3 px-4">₹{deployment.price.toLocaleString()}</td>
                        <td className="py-3 px-4">
                          <span className={`px-2 py-1 rounded-full text-xs ${
                            deployment.status === "approved" ? "bg-green-100 text-green-800" :
                            deployment.status === "rejected" ? "bg-red-100 text-red-800" :
                            "bg-yellow-100 text-yellow-800"
                          }`}>
                            {deployment.status}
                          </span>
                        </td>
                        <td className="py-3 px-4">{deployment.date}</td>
                        <td className="py-3 px-4">
                          {deployment.status === "pending" && (
                            <div className="flex space-x-2">
                              <Button 
                                variant="outline" 
                                size="sm" 
                                className="text-green-600 border-green-600 hover:bg-green-50"
                                onClick={() => updateDeploymentStatus(deployment.id, "approved")}
                              >
                                Approve
                              </Button>
                              <Button 
                                variant="outline" 
                                size="sm" 
                                className="text-red-600 border-red-600 hover:bg-red-50"
                                onClick={() => updateDeploymentStatus(deployment.id, "rejected")}
                              >
                                Reject
                              </Button>
                            </div>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </AdminLayout>
  );
}