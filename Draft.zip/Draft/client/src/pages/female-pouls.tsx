import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Helmet } from "react-helmet";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import ProductCard from "@/components/product/product-card";
import { FemalePoul } from "@/shared/schema";

export default function FemalePouls() {
  const [geneticsQuality, setGeneticsQuality] = useState<string>("");
  const [eggProduction, setEggProduction] = useState<string>("");
  const [sortBy, setSortBy] = useState<string>("popularity");
  
  const { data: femalePouls, isLoading } = useQuery({
    queryKey: ['/api/female-pouls', { geneticsQuality, eggProduction, sortBy }],
  });

  return (
    <>
      <Helmet>
        <title>Female Gaming Pouls - Premium Breeding Hens | Gaming Pouls</title>
        <meta name="description" content="High-quality female gaming pouls with superior genetics and egg production. Find the perfect breeding hen for your collection." />
      </Helmet>
    
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-2">Female Gaming Pouls</h2>
          <p className="text-dark-accent mb-8">Quality hens with superior genetics and egg production</p>
          
          {/* Filters */}
          <div className="mb-8 bg-background p-4 rounded-lg shadow-sm">
            <div className="flex flex-wrap gap-4">
              <div className="w-full md:w-auto">
                <Label className="block text-sm font-medium mb-1">Genetics Quality</Label>
                <Select value={geneticsQuality} onValueChange={setGeneticsQuality}>
                  <SelectTrigger className="w-full md:w-48">
                    <SelectValue placeholder="All Qualities" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">All Qualities</SelectItem>
                    <SelectItem value="standard">Standard</SelectItem>
                    <SelectItem value="premium">Premium</SelectItem>
                    <SelectItem value="elite">Elite</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="w-full md:w-auto">
                <Label className="block text-sm font-medium mb-1">Egg Production</Label>
                <Select value={eggProduction} onValueChange={setEggProduction}>
                  <SelectTrigger className="w-full md:w-48">
                    <SelectValue placeholder="All Rates" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">All Rates</SelectItem>
                    <SelectItem value="low">Low (1-3 per week)</SelectItem>
                    <SelectItem value="medium">Medium (4-5 per week)</SelectItem>
                    <SelectItem value="high">High (6+ per week)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="w-full md:w-auto">
                <Label className="block text-sm font-medium mb-1">Sort By</Label>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-full md:w-48">
                    <SelectValue placeholder="Popularity" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="popularity">Popularity</SelectItem>
                    <SelectItem value="price-low">Price: Low to High</SelectItem>
                    <SelectItem value="price-high">Price: High to Low</SelectItem>
                    <SelectItem value="newest">Newest First</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          
          {/* Product Grid */}
          {isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {[...Array(8)].map((_, index) => (
                <div key={index} className="bg-background rounded-lg overflow-hidden shadow-sm h-96 animate-pulse">
                  <div className="bg-gray-300 h-60"></div>
                  <div className="p-4">
                    <div className="h-6 bg-gray-300 rounded mb-2"></div>
                    <div className="h-4 bg-gray-200 rounded mb-3"></div>
                    <div className="h-4 bg-gray-200 rounded mb-3"></div>
                    <div className="h-10 bg-gray-300 rounded"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {femalePouls?.map((poul: FemalePoul) => (
                <ProductCard
                  key={poul.id}
                  id={poul.id}
                  name={poul.name}
                  price={poul.price}
                  image={poul.image}
                  description={poul.description}
                  badges={[poul.geneticsQuality]}
                  tags={[
                    { label: "Weight", value: `${poul.weight}kg` },
                    { label: "Age", value: `${poul.age} years` },
                    { label: "Eggs/week", value: poul.eggsPerWeek.toString() }
                  ]}
                />
              ))}
            </div>
          )}
          
          {/* Pagination - Static for now */}
          <div className="mt-8 flex justify-center">
            <div className="flex space-x-1">
              <a href="#" className="px-4 py-2 bg-background border rounded-md text-dark-accent hover:bg-gray-50">Previous</a>
              <a href="#" className="px-4 py-2 bg-primary border border-primary rounded-md text-white">1</a>
              <a href="#" className="px-4 py-2 bg-background border rounded-md text-dark-accent hover:bg-gray-50">2</a>
              <a href="#" className="px-4 py-2 bg-background border rounded-md text-dark-accent hover:bg-gray-50">Next</a>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
