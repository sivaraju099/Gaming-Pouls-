import { useQuery } from "@tanstack/react-query";
import { Helmet } from "react-helmet";
import ProductCard from "@/components/product/product-card";
import { EggCluster } from "@/shared/schema";

export default function EggClusters() {
  const { data: eggClusters, isLoading } = useQuery({
    queryKey: ['/api/egg-clusters'],
  });

  return (
    <>
      <Helmet>
        <title>Egg Clusters - Fresh Gaming Poul Eggs | Gaming Pouls</title>
        <meta name="description" content="Premium quality gaming poul eggs sold in various cluster sizes. Fresh eggs from champion bloodlines with excellent hatch rates." />
      </Helmet>
    
      <section className="py-12 bg-background">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-2">Egg Clusters</h2>
          <p className="text-dark-accent mb-8">Fresh eggs from premium gaming pouls</p>
          
          {/* Product Grid */}
          {isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {[...Array(6)].map((_, index) => (
                <div key={index} className="bg-white rounded-lg overflow-hidden shadow-sm h-80 animate-pulse">
                  <div className="bg-gray-300 h-60"></div>
                  <div className="p-4">
                    <div className="h-6 bg-gray-300 rounded mb-2"></div>
                    <div className="h-4 bg-gray-200 rounded mb-3"></div>
                    <div className="h-10 bg-gray-300 rounded"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {eggClusters?.map((cluster: EggCluster) => (
                <ProductCard
                  key={cluster.id}
                  id={cluster.id}
                  name={cluster.name}
                  price={cluster.price}
                  image={cluster.image}
                  description={cluster.description}
                  badges={cluster.isBestValue ? ["Best Value"] : []}
                  variant="centered"
                />
              ))}
            </div>
          )}
        </div>
      </section>
    </>
  );
}
