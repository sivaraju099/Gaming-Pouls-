import { Helmet } from "react-helmet";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function Help() {
  return (
    <>
      <Helmet>
        <title>Help & FAQ | Gaming Pouls</title>
        <meta name="description" content="Find answers to frequently asked questions about gaming pouls, shipping, payment options, and more." />
      </Helmet>
    
      <section className="py-12 bg-background">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-2">Help & FAQ</h2>
          <p className="text-dark-accent mb-8">Find answers to commonly asked questions</p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            <Card>
              <CardHeader>
                <CardTitle>Shipping & Delivery</CardTitle>
                <CardDescription>Learn about our shipping policies and delivery times</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="mb-4">We ensure safe and timely delivery of all orders, with special care for live animals.</p>
                <Button variant="outline" className="w-full" asChild>
                  <a href="#shipping">View Details</a>
                </Button>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Payment Options</CardTitle>
                <CardDescription>Information about secure payment methods</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="mb-4">We accept various payment methods including UPI, cards, and cash on delivery in select areas.</p>
                <Button variant="outline" className="w-full" asChild>
                  <a href="#payment">View Details</a>
                </Button>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Returns & Refunds</CardTitle>
                <CardDescription>Our policies for returns and refunds</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="mb-4">Learn about our return policy for products that don't meet your expectations.</p>
                <Button variant="outline" className="w-full" asChild>
                  <a href="#returns">View Details</a>
                </Button>
              </CardContent>
            </Card>
          </div>
          
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="item-1" id="shipping">
              <AccordionTrigger>How do you handle shipping of live pouls?</AccordionTrigger>
              <AccordionContent>
                <p>We use specialized carriers experienced in transporting live animals. All birds are transported in ventilated containers with appropriate bedding and water. We only ship when weather conditions are suitable for the birds' comfort and safety.</p>
                <p className="mt-2">Delivery times typically range from 1-3 days depending on your location. We'll provide tracking information so you can monitor your order.</p>
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-2">
              <AccordionTrigger>Do you ship eggs, and how do you ensure they arrive unbroken?</AccordionTrigger>
              <AccordionContent>
                <p>Yes, we ship eggs using specialized packaging designed to protect them during transit. Each egg is individually wrapped in cushioning material and placed in a sturdy container. We mark packages as fragile and use carriers experienced in transporting eggs.</p>
                <p className="mt-2">Please note that while we take every precaution, we cannot guarantee hatch rates as they depend on many factors including handling upon arrival and incubation conditions.</p>
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-3" id="payment">
              <AccordionTrigger>What payment methods do you accept?</AccordionTrigger>
              <AccordionContent>
                <p>We accept the following payment methods:</p>
                <ul className="list-disc ml-6 mt-2">
                  <li>UPI (Google Pay, PhonePe, Paytm)</li>
                  <li>Credit/Debit Cards</li>
                  <li>Net Banking</li>
                  <li>Cash on Delivery (for select areas)</li>
                </ul>
                <p className="mt-2">All online payments are processed through secure payment gateways.</p>
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-4" id="returns">
              <AccordionTrigger>What is your return policy?</AccordionTrigger>
              <AccordionContent>
                <p>Due to the nature of our products (live animals and eggs), we have a limited return policy:</p>
                <ul className="list-disc ml-6 mt-2">
                  <li>If birds arrive injured or unwell, contact us within 24 hours with photographic evidence.</li>
                  <li>If the bird is significantly different from what was described, contact us within 48 hours.</li>
                  <li>For non-living products, you have 7 days to return items in original packaging.</li>
                </ul>
                <p className="mt-2">All returns must be pre-approved by our customer service team.</p>
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-5">
              <AccordionTrigger>How do you determine the fighting skills of male pouls?</AccordionTrigger>
              <AccordionContent>
                <p>We assess fighting skills based on several factors:</p>
                <ul className="list-disc ml-6 mt-2">
                  <li>Bloodline and genetics</li>
                  <li>Physical attributes (stance, muscle tone, reflexes)</li>
                  <li>Training response and temperament</li>
                  <li>Previous fight performance (for older birds)</li>
                </ul>
                <p className="mt-2">Each bird is carefully evaluated by our experienced staff, and videos of training sessions or fights are available for most premium birds.</p>
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-6">
              <AccordionTrigger>Do you provide care instructions for the pouls?</AccordionTrigger>
              <AccordionContent>
                <p>Yes, we include detailed care instructions with every order. These instructions cover:</p>
                <ul className="list-disc ml-6 mt-2">
                  <li>Housing requirements</li>
                  <li>Feed recommendations</li>
                  <li>Health monitoring</li>
                  <li>Training tips (for fighting birds)</li>
                  <li>Breeding guidelines (for females)</li>
                </ul>
                <p className="mt-2">Our customer support team is also available to answer any specific questions about caring for your birds.</p>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
          
          <div className="mt-12 text-center">
            <h3 className="text-xl font-bold mb-4">Still have questions?</h3>
            <p className="text-dark-accent mb-6">Our team is ready to assist you with any inquiries you might have.</p>
            <Button size="lg" asChild>
              <Link href="/contact">Contact Us</Link>
            </Button>
          </div>
        </div>
      </section>
    </>
  );
}
