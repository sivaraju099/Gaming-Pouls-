import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Helmet } from "react-helmet";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import ProductCard from "@/components/product/product-card";

// Define the Chick interface locally
interface Chick {
  id: string;
  name: string;
  ageInMonths: number;
  ageDisplay: string;
  weight: number;
  price: number;
  image: string;
  description: string;
}

export default function Chicks() {
  const [ageFilter, setAgeFilter] = useState<string>("all-ages");
  const [sortBy, setSortBy] = useState<string>("price-low");
  
  const { data: chicks, isLoading } = useQuery({
    queryKey: ['/api/chicks', { ageFilter, sortBy }],
  });

  return (
    <>
      <Helmet>
        <title>Gaming Poul Chicks - Young Fowl for Sale | Gaming Pouls</title>
        <meta name="description" content="Young gaming poul chicks of various ages from champion bloodlines. Perfect for training and raising your own champion." />
      </Helmet>
    
      <section className="py-12 bg-background">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-2">Gaming Poul Chicks</h2>
          <p className="text-dark-accent mb-8">Young chicks from champion bloodlines</p>
          
          {/* Filters */}
          <div className="mb-8 bg-white p-4 rounded-lg shadow-sm">
            <div className="flex flex-wrap gap-4">
              <div className="w-full md:w-auto">
                <Label className="block text-sm font-medium mb-1">Age</Label>
                <Select value={ageFilter} onValueChange={setAgeFilter}>
                  <SelectTrigger className="w-full md:w-48">
                    <SelectValue placeholder="All Ages" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all-ages">All Ages</SelectItem>
                    <SelectItem value="1month">1 Month</SelectItem>
                    <SelectItem value="2months">2 Months</SelectItem>
                    <SelectItem value="3months">3 Months</SelectItem>
                    <SelectItem value="4plusmonths">4+ Months</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="w-full md:w-auto">
                <Label className="block text-sm font-medium mb-1">Sort By</Label>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-full md:w-48">
                    <SelectValue placeholder="Price: Low to High" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="price-low">Price: Low to High</SelectItem>
                    <SelectItem value="price-high">Price: High to Low</SelectItem>
                    <SelectItem value="age-young">Age: Youngest First</SelectItem>
                    <SelectItem value="age-old">Age: Oldest First</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          
          {/* Product Grid */}
          {isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {[...Array(8)].map((_, index) => (
                <div key={index} className="bg-white rounded-lg overflow-hidden shadow-sm h-80 animate-pulse">
                  <div className="bg-gray-300 h-60"></div>
                  <div className="p-4">
                    <div className="h-6 bg-gray-300 rounded mb-2"></div>
                    <div className="h-4 bg-gray-200 rounded mb-3"></div>
                    <div className="h-10 bg-gray-300 rounded"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {Array.isArray(chicks) && chicks.map((chick: Chick) => (
                <ProductCard
                  key={chick.id}
                  id={chick.id}
                  name={chick.name}
                  price={chick.price}
                  image={chick.image}
                  description={chick.description}
                  tags={[
                    { label: "Age", value: chick.ageDisplay },
                    { label: "Weight", value: `${chick.weight}kg` }
                  ]}
                />
              ))}
            </div>
          )}
        </div>
      </section>
    </>
  );
}
