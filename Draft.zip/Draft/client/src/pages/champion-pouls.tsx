import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Helmet } from "react-helmet";
import { Award, Trophy, Star } from "lucide-react";
import ProductCard from "@/components/product/product-card";
import { useCart } from "@/components/cart/cart-provider";

// Define the ChampionPoul interface
interface ChampionPoul {
  id: string;
  name: string;
  price: number;
  image: string;
  description: string;
  weight: number;
  age: number;
  wins: number;
  specialAbility: string;
  videoUrl?: string;
}

// Mock championship pouls data (over 3kg)
const championPouls: ChampionPoul[] = [
  {
    id: "cp1",
    name: "Titan Commander",
    price: 38500,
    image: "https://rurallivingtoday.com/wp-content/uploads/2018/04/fighting-birds.jpeg",
    description: "Our heavyweight champion with an impressive record of 15 wins. This 3.5kg fighter has unmatched power and strategy in the ring.",
    weight: 3.5,
    age: 3,
    wins: 15,
    specialAbility: "Knock-out power strike",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ"
  },
  {
    id: "cp2",
    name: "Supreme Warrior",
    price: 42000,
    image: "https://www.shutterstock.com/image-photo/thai-fighting-cock-farm-600nw-736520933.jpg",
    description: "A 3.8kg elite fighter known for his endurance and aggressive fighting style. Has been bred from a championship bloodline.",
    weight: 3.8,
    age: 4,
    wins: 12,
    specialAbility: "Exceptional endurance",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ"
  },
  {
    id: "cp3",
    name: "Thunder Emperor",
    price: 36000,
    image: "https://lirp.cdn-website.com/ac7cdf83/dms3rep/multi/opt/9-640w.png",
    description: "This 3.2kg champion is known for his precise and calculated attacks. Perfect for experienced trainers and serious competitions.",
    weight: 3.2,
    age: 3,
    wins: 10,
    specialAbility: "Tactical defensive strategy",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ"
  },
  {
    id: "cp4",
    name: "Colossus King",
    price: 45000,
    image: "https://cdn0.rubylane.com/_pod/item/1156352/RL-03086/Exceptional-Taxidermy-Fighting-Rooster-Cock-full-1o-720-92-f.jpg",
    description: "Our largest champion at 4.1kg with devastating power. This rare specimen commands respect with his presence alone.",
    weight: 4.1,
    age: 5,
    wins: 18,
    specialAbility: "Devastating power strikes",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ"
  },
  {
    id: "cp5",
    name: "Victory Legend",
    price: 39500,
    image: "https://www.shutterstock.com/image-photo/aseel-rooster-600nw-1196891096.jpg",
    description: "A 3.6kg champion with perfect balance of speed and power. Trained using traditional techniques passed down for generations.",
    weight: 3.6,
    age: 4,
    wins: 14,
    specialAbility: "Perfect form technique",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ"
  },
  {
    id: "cp6",
    name: "Dominator Prime",
    price: 52000,
    image: "https://upload.wikimedia.org/wikipedia/commons/thumb/e/e6/Fighting_Chicken_in_Kerala%2C_India.jpg/640px-Fighting_Chicken_in_Kerala%2C_India.jpg",
    description: "Our premium 3.9kg champion with a perfect record of 20-0. The most sought-after fighting poul for serious collectors and competitors.",
    weight: 3.9,
    age: 5,
    wins: 20,
    specialAbility: "Unbeatable instinct",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ"
  }
];

export default function ChampionPouls() {
  const [selectedChampion, setSelectedChampion] = useState<ChampionPoul | null>(null);
  const [videoDialogOpen, setVideoDialogOpen] = useState(false);
  const { addItem } = useCart();
  
  // In a real application, you would fetch this data from an API
  // For demonstration, we're using mock data
  const { data: champions = championPouls, isLoading } = useQuery({
    queryKey: ['/api/champion-pouls'],
    initialData: championPouls
  });

  const handleVideoClick = (champion: ChampionPoul) => {
    setSelectedChampion(champion);
    setVideoDialogOpen(true);
  };
  
  const handleAddToCart = (champion: ChampionPoul) => {
    addItem({
      id: champion.id,
      name: champion.name,
      price: champion.price,
      image: champion.image
    });
  };

  return (
    <>
      <Helmet>
        <title>Heavyweight Champion Pouls | Gaming Pouls</title>
        <meta name="description" content="Exclusive collection of heavyweight champion fighting pouls over 3kg. Premium genetics, proven winners, and elite bloodlines." />
      </Helmet>

      {/* Hero Section */}
      <section className="relative py-16 bg-gradient-to-r from-primary/90 to-secondary/90 text-white">
        <div className="absolute inset-0 bg-black/40 z-0"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Heavyweight Champion Pouls</h1>
            <p className="text-xl opacity-90 mb-8">
              Exclusive collection of elite fighters weighing over 3kg with proven records and exceptional genetics
            </p>
            <div className="flex flex-wrap gap-4 items-center">
              <div className="flex items-center">
                <Trophy className="h-6 w-6 text-yellow-300 mr-2" />
                <span>Competition Grade</span>
              </div>
              <div className="flex items-center">
                <Award className="h-6 w-6 text-yellow-300 mr-2" />
                <span>Championship Bloodlines</span>
              </div>
              <div className="flex items-center">
                <Star className="h-6 w-6 text-yellow-300 mr-2" />
                <span>Premium Selection</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Champion Collection Section */}
      <section className="py-16 bg-accent">
        <div className="container mx-auto px-4">
          <h2 className="section-title">Our Championship Collection</h2>
          <p className="text-center text-gray-600 max-w-3xl mx-auto mb-12">
            Each of our heavyweight champions exceeds 3kg and has been carefully selected for their superior genetics, 
            fighting prowess, and championship bloodlines. These elite fighters represent the pinnacle of quality.
          </p>
          
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[...Array(6)].map((_, index) => (
                <div key={index} className="bg-white rounded-lg overflow-hidden shadow-sm h-96 animate-pulse">
                  <div className="bg-gray-300 h-60"></div>
                  <div className="p-4">
                    <div className="h-6 bg-gray-300 rounded mb-2"></div>
                    <div className="h-4 bg-gray-200 rounded mb-3"></div>
                    <div className="h-10 bg-gray-300 rounded"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {champions.map((champion) => (
                <div key={champion.id} className="product-card overflow-hidden bg-white rounded-lg shadow-md">
                  <div className="product-image h-64 relative">
                    <img 
                      src={champion.image} 
                      alt={champion.name} 
                      className="object-cover w-full h-full"
                    />
                    <div className="absolute top-0 right-0 m-2">
                      <span className="badge">
                        {champion.weight}kg
                      </span>
                    </div>
                    {champion.videoUrl && (
                      <button 
                        className="absolute bottom-3 right-3 bg-white/80 hover:bg-white p-2 rounded-full transition-colors"
                        onClick={() => handleVideoClick(champion)}
                      >
                        <span className="sr-only">Watch video</span>
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                      </button>
                    )}
                  </div>
                  <div className="p-4">
                    <h3 className="text-xl font-bold mb-2">{champion.name}</h3>
                    <p className="product-price mb-2">₹{champion.price.toLocaleString()}</p>
                    <div className="flex flex-wrap gap-2 mb-4">
                      <span className="px-2 py-1 bg-primary/10 text-primary text-xs rounded-full">{champion.wins} Wins</span>
                      <span className="px-2 py-1 bg-primary/10 text-primary text-xs rounded-full">{champion.age} Years</span>
                      <span className="px-2 py-1 bg-secondary/10 text-secondary text-xs rounded-full">{champion.specialAbility}</span>
                    </div>
                    <p className="text-gray-600 text-sm mb-4 line-clamp-2">{champion.description}</p>
                    <button 
                      className="w-full py-2 bg-primary text-white rounded-md hover:bg-primary/90 transition-colors"
                      onClick={() => handleAddToCart(champion)}
                    >
                      Add to Cart
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Champion Quality Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="section-title">Why Choose Our Champions</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
            <div className="text-center">
              <div className="w-16 h-16 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <Trophy className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-2">Superior Genetics</h3>
              <p className="text-gray-600">
                Our heavyweight champions come from carefully selected bloodlines that have been perfected over generations for optimal performance.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <Award className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-2">Proven Winners</h3>
              <p className="text-gray-600">
                Every champion in our collection has a verified track record of wins in competition, ensuring you receive a proven fighter.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <Star className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-2">Elite Training</h3>
              <p className="text-gray-600">
                Our champions undergo rigorous training programs to develop their natural abilities and fighting techniques.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Video Dialog for champion videos */}
      {selectedChampion && (
        <div className={`fixed inset-0 z-50 flex items-center justify-center ${videoDialogOpen ? 'block' : 'hidden'}`}>
          <div className="absolute inset-0 bg-black/70" onClick={() => setVideoDialogOpen(false)}></div>
          <div className="relative bg-white rounded-lg overflow-hidden max-w-4xl w-full mx-4">
            <div className="p-4 border-b flex justify-between items-center">
              <h3 className="font-bold text-lg">{selectedChampion.name} - Fighting Demonstration</h3>
              <button onClick={() => setVideoDialogOpen(false)} className="text-gray-500 hover:text-gray-700">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            <div className="aspect-video">
              {selectedChampion.videoUrl && (
                <iframe
                  width="100%"
                  height="100%"
                  src={selectedChampion.videoUrl}
                  title="Champion Video"
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                ></iframe>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}