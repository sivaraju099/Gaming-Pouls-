import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Helmet } from "react-helmet";
import { Button } from "@/components/ui/button";
import QuantitySelector from "@/components/product/quantity-selector";
import { useCart } from "@/components/cart/cart-provider";
import { formatCurrency } from "@/lib/utils";
import { VillageHen, VillageEgg } from "@/shared/schema";

export default function VillageHens() {
  const { data: products, isLoading } = useQuery({
    queryKey: ['/api/village-products'],
  });
  
  const [henWeight, setHenWeight] = useState(1);
  const [eggCount, setEggCount] = useState(10);
  const { addItem } = useCart();
  
  const villageHen: VillageHen | undefined = products?.hen;
  const villageEgg: VillageEgg | undefined = products?.egg;
  
  const henPrice = villageHen ? villageHen.pricePerKg * henWeight : 0;
  const eggPrice = villageEgg ? villageEgg.pricePerEgg * eggCount : 0;
  
  const handleAddHenToCart = () => {
    if (villageHen) {
      addItem({
        id: `village-hen-${henWeight}`,
        name: `Village Hen (${henWeight}kg)`,
        price: henPrice,
        image: villageHen.image
      });
    }
  };
  
  const handleAddEggsToCart = () => {
    if (villageEgg) {
      addItem({
        id: `village-egg-${eggCount}`,
        name: `Village Eggs (${eggCount} eggs)`,
        price: eggPrice,
        image: villageEgg.image
      });
    }
  };

  return (
    <>
      <Helmet>
        <title>Village Hens and Eggs | Gaming Pouls</title>
        <meta name="description" content="Traditional free-range village hens and fresh eggs. Buy by weight or quantity. Natural, healthy, and antibiotic-free." />
      </Helmet>
    
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-2">Village Hens</h2>
          <p className="text-dark-accent mb-8">Traditional free-range hens and their eggs</p>
          
          {isLoading ? (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {[...Array(2)].map((_, index) => (
                <div key={index} className="bg-background rounded-lg overflow-hidden shadow-sm animate-pulse">
                  <div className="bg-gray-300 h-80"></div>
                  <div className="p-6">
                    <div className="h-8 bg-gray-300 rounded mb-3"></div>
                    <div className="h-4 bg-gray-200 rounded mb-6"></div>
                    <div className="h-20 bg-gray-200 rounded mb-6"></div>
                    <div className="h-12 bg-gray-300 rounded"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Village Hens */}
              <div className="bg-background rounded-lg overflow-hidden shadow-sm">
                <div className="relative h-80">
                  {villageHen?.image && (
                    <img 
                      src={villageHen.image} 
                      alt="Village Hen" 
                      className="w-full h-full object-cover" 
                    />
                  )}
                </div>
                <div className="p-6">
                  <h3 className="font-bold text-xl mb-3">Village Hens ({formatCurrency(villageHen?.pricePerKg || 0)} per kg)</h3>
                  <p className="text-dark-accent mb-6">{villageHen?.description}</p>
                  
                  <div className="mb-6">
                    <QuantitySelector
                      quantity={henWeight}
                      onQuantityChange={setHenWeight}
                      min={1}
                      max={5}
                      label="Select Weight (kg)"
                    />
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <div className="text-xl font-bold">
                      Total: <span className="text-primary">{formatCurrency(henPrice)}</span>
                    </div>
                    <Button onClick={handleAddHenToCart}>
                      Add to Cart
                    </Button>
                  </div>
                </div>
              </div>
              
              {/* Village Eggs */}
              <div className="bg-background rounded-lg overflow-hidden shadow-sm">
                <div className="relative h-80">
                  {villageEgg?.image && (
                    <img 
                      src={villageEgg.image}
                      alt="Village Eggs" 
                      className="w-full h-full object-cover" 
                    />
                  )}
                </div>
                <div className="p-6">
                  <h3 className="font-bold text-xl mb-3">Village Eggs ({formatCurrency(villageEgg?.pricePerEgg || 0)} per egg)</h3>
                  <p className="text-dark-accent mb-6">{villageEgg?.description}</p>
                  
                  <div className="mb-6">
                    <QuantitySelector
                      quantity={eggCount}
                      onQuantityChange={setEggCount}
                      min={1}
                      max={50}
                      label="Number of Eggs"
                    />
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <div className="text-xl font-bold">
                      Total: <span className="text-primary">{formatCurrency(eggPrice)}</span>
                    </div>
                    <Button onClick={handleAddEggsToCart}>
                      Add to Cart
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </section>
    </>
  );
}
