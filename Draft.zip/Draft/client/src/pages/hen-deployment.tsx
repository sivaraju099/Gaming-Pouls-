import { useState } from "react";
import { useLocation } from "wouter";
import { Helmet } from "react-helmet";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Upload } from "lucide-react";

// Define the form schema using zod
const deploymentFormSchema = z.object({
  customerName: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Please enter a valid email address"),
  phone: z.string().min(10, "Please enter a valid phone number"),
  henName: z.string().min(2, "Hen name must be at least 2 characters"),
  henType: z.enum(["male", "female", "chick"], {
    required_error: "Please select a hen type",
  }),
  henAge: z.string().min(1, "Please specify the age"),
  price: z.string().min(1, "Please specify your expected price"),
  description: z.string().min(10, "Description must be at least 10 characters"),
});

type DeploymentFormValues = z.infer<typeof deploymentFormSchema>;

export default function HenDeployment() {
  const [_, navigate] = useLocation();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  // Set up the form with zod validation
  const form = useForm<DeploymentFormValues>({
    resolver: zodResolver(deploymentFormSchema),
    defaultValues: {
      customerName: "",
      email: "",
      phone: "",
      henName: "",
      henType: "male",
      henAge: "",
      price: "",
      description: "",
    },
  });

  const onSubmit = async (data: DeploymentFormValues) => {
    setIsSubmitting(true);
    
    // In a real application, you would submit this data to your API
    // For demonstration, we're just showing a success message
    
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      toast({
        title: "Deployment Request Submitted",
        description: "Your hen deployment request has been submitted successfully. We'll review and get back to you soon.",
      });
      
      // Reset the form
      form.reset();
      setImagePreview(null);
      
      // Redirect to home after a short delay
      setTimeout(() => {
        navigate("/");
      }, 2000);
    } catch (error) {
      toast({
        title: "Submission Failed",
        description: "There was an error submitting your request. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle image upload
  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    
    // Check file type
    if (!file.type.startsWith("image/")) {
      toast({
        title: "Invalid File",
        description: "Please select an image file",
        variant: "destructive",
      });
      return;
    }
    
    // Check file size (limit to 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "File Too Large",
        description: "Image size should be less than 5MB",
        variant: "destructive",
      });
      return;
    }
    
    // Create a preview URL
    const reader = new FileReader();
    reader.onload = (e) => {
      setImagePreview(e.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  return (
    <>
      <Helmet>
        <title>Deploy Your Hen | Gaming Pouls</title>
        <meta name="description" content="Submit your hen for deployment on our platform. Sell your quality pouls to our large customer base." />
      </Helmet>

      <section className="py-12 bg-accent">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-8">
              <h1 className="text-3xl font-bold mb-2">Deploy Your Hen</h1>
              <p className="text-gray-600">Submit your hen for sale on our platform and reach thousands of enthusiasts</p>
            </div>
            
            <div className="bg-white rounded-lg shadow-lg p-6 md:p-8">
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Personal Information */}
                    <div className="space-y-4">
                      <h2 className="text-xl font-semibold">Your Information</h2>
                      
                      <FormField
                        control={form.control}
                        name="customerName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Full Name</FormLabel>
                            <FormControl>
                              <Input placeholder="Your full name" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="your.email@example.com" 
                                type="email" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="phone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Phone Number</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Your contact number" 
                                type="tel" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    {/* Hen Information */}
                    <div className="space-y-4">
                      <h2 className="text-xl font-semibold">Hen Details</h2>
                      
                      <FormField
                        control={form.control}
                        name="henName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Hen Name</FormLabel>
                            <FormControl>
                              <Input placeholder="Name of your hen" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="henType"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Type</FormLabel>
                            <select
                              className="w-full p-2 border rounded-md bg-white"
                              {...field}
                            >
                              <option value="male">Male Poul</option>
                              <option value="female">Female Poul</option>
                              <option value="chick">Chick</option>
                            </select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="henAge"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Age</FormLabel>
                              <FormControl>
                                <Input placeholder="Age in months" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="price"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Expected Price (₹)</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="Asking price" 
                                  type="number" 
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                  </div>
                  
                  {/* Description */}
                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Provide details about your hen including genetics, fighting abilities, or egg production capabilities" 
                            rows={5}
                            {...field} 
                          />
                        </FormControl>
                        <FormDescription>
                          Include important details like weight, special traits, achievements, and breeding information.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  {/* Image Upload */}
                  <div className="space-y-4">
                    <FormLabel>Upload Hen Image</FormLabel>
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 flex flex-col items-center justify-center">
                      {imagePreview ? (
                        <div className="space-y-4 w-full">
                          <img 
                            src={imagePreview} 
                            alt="Preview" 
                            className="max-h-40 mx-auto object-contain"
                          />
                          <div className="flex justify-center">
                            <Button 
                              type="button" 
                              variant="outline" 
                              onClick={() => setImagePreview(null)}
                            >
                              Remove Image
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <>
                          <Upload className="h-12 w-12 text-gray-400 mb-2" />
                          <p className="text-sm text-gray-600 mb-2">
                            Click to upload or drag and drop
                          </p>
                          <p className="text-xs text-gray-500">
                            SVG, PNG, JPG or GIF (Max 5MB)
                          </p>
                          <input
                            type="file"
                            accept="image/*"
                            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                            onChange={handleImageUpload}
                          />
                        </>
                      )}
                    </div>
                  </div>
                  
                  <div className="border-t pt-6">
                    <div className="flex justify-end space-x-4">
                      <Button 
                        type="button" 
                        variant="outline" 
                        onClick={() => navigate("/")}
                      >
                        Cancel
                      </Button>
                      <Button 
                        type="submit" 
                        className="btn-primary" 
                        disabled={isSubmitting}
                      >
                        {isSubmitting ? "Submitting..." : "Submit Deployment Request"}
                      </Button>
                    </div>
                  </div>
                </form>
              </Form>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}