import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Helmet } from "react-helmet";
import { Button } from "@/components/ui/button";
import { ArrowRight, Award, Shield, Users, Trophy, Star } from "lucide-react";

// Define CategoryPreview interface locally
interface CategoryPreview {
  id: string;
  name: string;
  slug: string;
  image: string;
}

export default function Home() {
  const { data: categories, isLoading } = useQuery({
    queryKey: ['/api/categories'],
  });
  
  const [_, navigate] = useLocation();

  return (
    <>
      <Helmet>
        <title>Gaming Pouls - Premium Fighting Fowl</title>
        <meta name="description" content="Discover championship-quality fighting fowl with exceptional fighting skills, genetics, and breeding history." />
      </Helmet>
    
      {/* Hero Section - Enhanced with new styles */}
      <section className="hero-section">
        <div 
          className="absolute inset-0 bg-cover bg-center" 
          style={{
            backgroundImage: "url('https://pixabay.com/get/g23edd2b18a24d62d9b645106061bafce6bb26f2c6e055ec27444e7e6814bc24cbc415c226f34c6d7aa85d30d108b1ac5c1c39bf7016283b7d806186ddf7cdce8_1280.jpg')",
            opacity: 0.7
          }}
        />
        
        <div className="container mx-auto hero-content">
          <div className="max-w-2xl animate-fade-in">
            <h1 className="hero-title">Premium Gaming Pouls for Enthusiasts</h1>
            <p className="hero-description">Discover championship-quality fowl with exceptional fighting skills, genetics, and breeding history.</p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                size="lg" 
                className="btn-primary w-full"
                onClick={() => navigate("/male-pouls")}
              >
                Shop Male Pouls <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="btn-outline w-full"
                onClick={() => navigate("/female-pouls")}
              >
                Shop Female Pouls <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Heavyweight Champions Promo Section */}
      <section className="py-12 bg-gradient-to-r from-primary/10 to-secondary/10">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center gap-8">
            <div className="md:w-1/2">
              <div className="relative">
                <img 
                  src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e6/Fighting_Chicken_in_Kerala%2C_India.jpg/640px-Fighting_Chicken_in_Kerala%2C_India.jpg" 
                  alt="Heavyweight Champion Poul" 
                  className="rounded-lg shadow-xl object-cover w-full max-h-[400px]"
                />
                <div className="absolute top-4 right-4 bg-primary text-white font-bold py-2 px-4 rounded-full transform rotate-3 shadow-lg">
                  NEW ARRIVAL
                </div>
              </div>
            </div>
            <div className="md:w-1/2">
              <h2 className="text-3xl font-bold mb-4">Exclusive Heavyweight Champions</h2>
              <p className="text-lg mb-6">
                Introducing our premium collection of championship fighting pouls weighing over 3kg. These elite fighters represent the best in genetics, training, and performance.
              </p>
              <ul className="space-y-3 mb-6">
                <li className="flex items-center">
                  <span className="bg-primary/20 p-1 rounded-full mr-2">
                    <Award className="h-5 w-5 text-primary" />
                  </span>
                  <span>Premium championship bloodlines</span>
                </li>
                <li className="flex items-center">
                  <span className="bg-primary/20 p-1 rounded-full mr-2">
                    <Trophy className="h-5 w-5 text-primary" />
                  </span>
                  <span>Proven winners with verified records</span>
                </li>
                <li className="flex items-center">
                  <span className="bg-primary/20 p-1 rounded-full mr-2">
                    <Star className="h-5 w-5 text-primary" />
                  </span>
                  <span>All pouls over 3kg with exceptional strength</span>
                </li>
              </ul>
              <Button 
                size="lg" 
                className="btn-primary"
                onClick={() => navigate("/champion-pouls")}
              >
                Explore Heavyweight Champions <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Benefits */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="flex flex-col items-center text-center p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <Award className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-2">Premium Quality</h3>
              <p className="text-gray-600">Our gaming pouls are bred from championship bloodlines ensuring superior genetics.</p>
            </div>
            
            <div className="flex flex-col items-center text-center p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <Shield className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-2">Health Guarantee</h3>
              <p className="text-gray-600">All our pouls come with a health guarantee and proper vaccination records.</p>
            </div>
            
            <div className="flex flex-col items-center text-center p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <Users className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-2">Expert Support</h3>
              <p className="text-gray-600">Our team of experts is available to provide guidance on care and training.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Categories Section - Enhanced with new styles */}
      <section className="py-16 bg-accent">
        <div className="container mx-auto px-4">
          <h2 className="section-title">Browse Categories</h2>
          
          {isLoading ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
              {[...Array(5)].map((_, index) => (
                <div key={index} className="h-48 bg-gray-200 rounded-lg animate-pulse"></div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
              {Array.isArray(categories) && categories.map((category: CategoryPreview) => (
                <div 
                  key={category.id} 
                  className="product-card h-64 cursor-pointer"
                  onClick={() => navigate(`/${category.slug}`)}
                >
                  <div className="product-image">
                    <img 
                      src={category.image} 
                      alt={category.name} 
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
                  </div>
                  <div className="absolute bottom-0 left-0 p-4 w-full">
                    <h3 className="text-white font-bold text-xl mb-1">{category.name}</h3>
                    <button 
                      className="text-white text-sm flex items-center hover:underline"
                      onClick={(e) => {
                        e.stopPropagation();
                        navigate(`/${category.slug}`);
                      }}
                    >
                      View Collection <ArrowRight className="ml-1 h-3 w-3" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Admin Login Link */}
      <div className="text-center py-8 text-sm text-gray-500">
        <button 
          className="hover:text-primary transition-colors"
          onClick={() => navigate("/admin/login")}
        >
          Admin Login
        </button>
      </div>
    </>
  );
}
