import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Helmet } from "react-helmet";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import ProductCard from "@/components/product/product-card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

// Define the MalePoul interface locally to avoid schema dependency
interface MalePoul {
  id: string;
  name: string;
  price: number;
  image: string;
  description: string;
  skillLevel: string;
  weight: number;
  age: number;
  wins: number;
  videoUrl?: string;
}

export default function MalePouls() {
  const [fightingSkill, setFightingSkill] = useState<string>("all-levels");
  const [weightRange, setWeightRange] = useState<string>("all-weights");
  const [sortBy, setSortBy] = useState<string>("popularity");
  const [videoDialogOpen, setVideoDialogOpen] = useState(false);
  const [selectedVideo, setSelectedVideo] = useState<string | null>(null);
  
  const { data: malePouls, isLoading } = useQuery({
    queryKey: ['/api/male-pouls', { fightingSkill, weightRange, sortBy }],
  });

  const handleVideoClick = (videoUrl: string) => {
    setSelectedVideo(videoUrl);
    setVideoDialogOpen(true);
  };

  return (
    <>
      <Helmet>
        <title>Male Gaming Pouls - Fighting Fowl | Gaming Pouls</title>
        <meta name="description" content="Shop premium male gaming pouls with exceptional fighting skills. Filter by fighting skill level, weight range, and more." />
      </Helmet>
    
      <section className="py-12 bg-background">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-2">Male Gaming Pouls</h2>
          <p className="text-dark-accent mb-8">Premium fighting fowl with exceptional skills and pedigree</p>
          
          {/* Filters */}
          <div className="mb-8 bg-white p-4 rounded-lg shadow-sm">
            <div className="flex flex-wrap gap-4">
              <div className="w-full md:w-auto">
                <Label className="block text-sm font-medium mb-1">Fighting Skill</Label>
                <Select value={fightingSkill} onValueChange={setFightingSkill}>
                  <SelectTrigger className="w-full md:w-48">
                    <SelectValue placeholder="All Skill Levels" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all-levels">All Skill Levels</SelectItem>
                    <SelectItem value="beginner">Beginner</SelectItem>
                    <SelectItem value="intermediate">Intermediate</SelectItem>
                    <SelectItem value="advanced">Advanced</SelectItem>
                    <SelectItem value="pro">Professional</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="w-full md:w-auto">
                <Label className="block text-sm font-medium mb-1">Weight Range</Label>
                <Select value={weightRange} onValueChange={setWeightRange}>
                  <SelectTrigger className="w-full md:w-48">
                    <SelectValue placeholder="All Weights" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all-weights">All Weights</SelectItem>
                    <SelectItem value="lightweight">1.5-2.0 kg</SelectItem>
                    <SelectItem value="middleweight">2.0-2.5 kg</SelectItem>
                    <SelectItem value="heavyweight">2.5+ kg</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="w-full md:w-auto">
                <Label className="block text-sm font-medium mb-1">Sort By</Label>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-full md:w-48">
                    <SelectValue placeholder="Popularity" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="popularity">Popularity</SelectItem>
                    <SelectItem value="price-low">Price: Low to High</SelectItem>
                    <SelectItem value="price-high">Price: High to Low</SelectItem>
                    <SelectItem value="newest">Newest First</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          
          {/* Product Grid */}
          {isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {[...Array(8)].map((_, index) => (
                <div key={index} className="bg-white rounded-lg overflow-hidden shadow-sm h-96 animate-pulse">
                  <div className="bg-gray-300 h-60"></div>
                  <div className="p-4">
                    <div className="h-6 bg-gray-300 rounded mb-2"></div>
                    <div className="h-4 bg-gray-200 rounded mb-3"></div>
                    <div className="h-4 bg-gray-200 rounded mb-3"></div>
                    <div className="h-10 bg-gray-300 rounded"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {Array.isArray(malePouls) && malePouls.map((poul: MalePoul) => (
                <ProductCard
                  key={poul.id}
                  id={poul.id}
                  name={poul.name}
                  price={poul.price}
                  image={poul.image}
                  description={poul.description}
                  badges={[poul.skillLevel]}
                  tags={[
                    { label: "Weight", value: `${poul.weight}kg` },
                    { label: "Age", value: `${poul.age} years` },
                    { label: poul.wins > 0 ? `${poul.wins} wins` : "Training", value: "N/A" }
                  ]}
                  hasVideo={Boolean(poul.videoUrl)}
                  onVideoClick={() => handleVideoClick(poul.videoUrl || "")}
                />
              ))}
            </div>
          )}
          
          {/* Pagination - Static for now */}
          <div className="mt-8 flex justify-center">
            <div className="flex space-x-1">
              <button className="px-4 py-2 bg-white border rounded-md text-dark-accent hover:bg-gray-50">Previous</button>
              <button className="px-4 py-2 bg-primary border border-primary rounded-md text-white">1</button>
              <button className="px-4 py-2 bg-white border rounded-md text-dark-accent hover:bg-gray-50">2</button>
              <button className="px-4 py-2 bg-white border rounded-md text-dark-accent hover:bg-gray-50">3</button>
              <button className="px-4 py-2 bg-white border rounded-md text-dark-accent hover:bg-gray-50">Next</button>
            </div>
          </div>
        </div>
      </section>
      
      {/* Video Dialog */}
      <Dialog open={videoDialogOpen} onOpenChange={setVideoDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Fighting Video</DialogTitle>
          </DialogHeader>
          <div className="aspect-video">
            {selectedVideo && (
              <iframe
                width="100%"
                height="100%"
                src={selectedVideo}
                title="Fight Video"
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              ></iframe>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
