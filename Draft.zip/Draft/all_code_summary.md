# Gaming Pouls E-commerce Website - Complete Code

This document contains all the key code files for the Gaming Pouls e-commerce website. Each section shows the file path and its contents.

## Main Application Files

### client/src/App.tsx
```tsx
import { Switch, Route, useLocation } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Toaster } from "@/components/ui/toaster";
import { CartProvider } from "./components/cart/cart-provider";
import NotFound from "@/pages/not-found";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import Home from "@/pages/home";
import MalePouls from "@/pages/male-pouls";
import FemalePouls from "@/pages/female-pouls";
import EggClusters from "@/pages/egg-clusters";
import VillageHens from "@/pages/village-hens";
import Chicks from "@/pages/chicks";
import Contact from "@/pages/contact";
import Help from "@/pages/help";
import CartDrawer from "@/components/cart/cart-drawer";
import AdminLogin from "@/pages/admin/login";
import AdminDashboard from "@/pages/admin/dashboard";

// Import all pages directly for now to avoid loading issues
import { Suspense } from "react";
import HenDeployment from "./pages/hen-deployment";
import ChampionPouls from "./pages/champion-pouls";

function Router() {
  const [location] = useLocation();
  const isAdminRoute = location.startsWith("/admin");

  return (
    <Suspense fallback={<div className="flex justify-center items-center min-h-screen">Loading...</div>}>
      <Switch>
        {/* Main site routes */}
        <Route path="/" component={Home} />
        <Route path="/male-pouls" component={MalePouls} />
        <Route path="/female-pouls" component={FemalePouls} />
        <Route path="/egg-clusters" component={EggClusters} />
        <Route path="/village-hens" component={VillageHens} />
        <Route path="/chicks" component={Chicks} />
        <Route path="/champion-pouls" component={ChampionPouls} />
        <Route path="/contact" component={Contact} />
        <Route path="/help" component={Help} />
        <Route path="/hen-deployment" component={HenDeployment} />
        
        {/* Admin routes */}
        <Route path="/admin/login" component={AdminLogin} />
        <Route path="/admin/dashboard" component={AdminDashboard} />
        
        {/* 404 route */}
        <Route component={NotFound} />
      </Switch>
    </Suspense>
  );
}

function App() {
  const [location] = useLocation();
  const isAdminRoute = location.startsWith("/admin");

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <CartProvider>
          {!isAdminRoute ? (
            <div className="flex flex-col min-h-screen">
              <Header />
              <main className="flex-grow">
                <Router />
              </main>
              <Footer />
              <CartDrawer />
            </div>
          ) : (
            <Router />
          )}
          <Toaster />
        </CartProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
```

### client/src/main.tsx
```tsx
import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

createRoot(document.getElementById("root")!).render(
  <App />
);
```

### client/src/components/cart/cart-provider.tsx
```tsx
import { createContext, useContext, useState, ReactNode, useEffect } from "react";

// Define the cart item interface
export interface CartItem {
  id: string;
  name: string;
  price: number;
  image: string;
  quantity: number;
}

// Define the cart context type
interface CartContextType {
  items: CartItem[];
  isCartOpen: boolean;
  addItem: (item: Omit<CartItem, 'quantity'>, quantity?: number) => void;
  removeItem: (id: string) => void;
  updateQuantity: (id: string, quantity: number) => void;
  clearCart: () => void;
  toggleCartOpen: () => void;
  closeCart: () => void;
}

// Create the default values for the cart context
const defaultCartContextValue: CartContextType = {
  items: [],
  isCartOpen: false,
  addItem: () => {},
  removeItem: () => {},
  updateQuantity: () => {},
  clearCart: () => {},
  toggleCartOpen: () => {},
  closeCart: () => {}
};

// Create the cart context
const CartContext = createContext<CartContextType>(defaultCartContextValue);

// Create a hook to use the cart context
export const useCart = () => {
  const context = useContext(CartContext);
  return context;
};

// Create the cart provider component
interface CartProviderProps {
  children: ReactNode;
}

export const CartProvider = ({ children }: CartProviderProps) => {
  const [items, setItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  
  // Load cart from localStorage on mount
  useEffect(() => {
    try {
      const savedCart = localStorage.getItem('cart');
      if (savedCart) {
        setItems(JSON.parse(savedCart));
      }
    } catch (e) {
      console.error('Failed to parse cart from localStorage:', e);
    }
  }, []);
  
  // Save cart to localStorage when it changes
  useEffect(() => {
    try {
      localStorage.setItem('cart', JSON.stringify(items));
    } catch (e) {
      console.error('Failed to save cart to localStorage:', e);
    }
  }, [items]);

  const addItem = (item: Omit<CartItem, 'quantity'>, quantity = 1) => {
    setItems(currentItems => {
      const existingItemIndex = currentItems.findIndex(
        existingItem => existingItem.id === item.id
      );
      
      if (existingItemIndex > -1) {
        const updatedItems = [...currentItems];
        updatedItems[existingItemIndex].quantity += quantity;
        return updatedItems;
      } else {
        return [...currentItems, { ...item, quantity }];
      }
    });
    
    // Open cart when adding item
    setIsCartOpen(true);
  };

  const removeItem = (id: string) => {
    setItems(currentItems => 
      currentItems.filter(item => item.id !== id)
    );
  };

  const updateQuantity = (id: string, quantity: number) => {
    if (quantity < 1) return;
    
    setItems(currentItems => 
      currentItems.map(item => 
        item.id === id ? { ...item, quantity } : item
      )
    );
  };

  const clearCart = () => {
    setItems([]);
  };
  
  const toggleCartOpen = () => {
    setIsCartOpen(!isCartOpen);
  };
  
  const closeCart = () => {
    setIsCartOpen(false);
  };

  const value = {
    items,
    isCartOpen,
    addItem,
    removeItem,
    updateQuantity,
    clearCart,
    toggleCartOpen,
    closeCart
  };

  return (
    <CartContext.Provider value={value}>
      {children}
    </CartContext.Provider>
  );
};
```

### client/src/components/layout/header.tsx
```tsx
import { useState } from "react";
import { Link, useLocation } from "wouter";
import Logo from "@/components/ui/logo";
import { ShoppingCart, Menu } from "lucide-react";
import MobileMenu from "./mobile-menu";
import { useCart } from "@/components/cart/cart-provider";

export default function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { items, toggleCartOpen } = useCart();
  const [location, navigate] = useLocation();
  
  const cartItemsCount = items.reduce((total, item) => total + item.quantity, 0);

  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center cursor-pointer" onClick={() => navigate("/")}>
            <Logo />
          </div>
          
          {/* Main Navigation */}
          <nav className="hidden md:flex space-x-8">
            <div 
              className="font-medium hover:text-primary transition-colors cursor-pointer"
              onClick={() => navigate("/")}
            >
              Home
            </div>
            <div className="relative group">
              <button className="font-medium hover:text-primary transition-colors flex items-center">
                View the Pouls <span className="ml-1 text-xs">▼</span>
              </button>
              <div className="absolute left-0 mt-2 w-64 bg-white shadow-lg rounded-md opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 z-50">
                <div 
                  className="block px-4 py-2 hover:bg-gray-100 cursor-pointer"
                  onClick={() => navigate("/male-pouls")}
                >
                  Male Pouls
                </div>
                <div 
                  className="block px-4 py-2 hover:bg-gray-100 cursor-pointer font-bold text-primary flex items-center"
                  onClick={() => navigate("/champion-pouls")}
                >
                  Heavyweight Champions (3kg+)
                  <span className="ml-2 px-1.5 py-0.5 rounded bg-primary text-white text-xs">NEW</span>
                </div>
                <div 
                  className="block px-4 py-2 hover:bg-gray-100 cursor-pointer"
                  onClick={() => navigate("/female-pouls")}
                >
                  Female Pouls
                </div>
                <div 
                  className="block px-4 py-2 hover:bg-gray-100 cursor-pointer"
                  onClick={() => navigate("/egg-clusters")}
                >
                  Egg Clusters
                </div>
                <div 
                  className="block px-4 py-2 hover:bg-gray-100 cursor-pointer"
                  onClick={() => navigate("/village-hens")}
                >
                  Village Hens
                </div>
                <div 
                  className="block px-4 py-2 hover:bg-gray-100 cursor-pointer"
                  onClick={() => navigate("/chicks")}
                >
                  Baby Pouls (Chicks)
                </div>
              </div>
            </div>
            <div 
              className="font-medium hover:text-primary transition-colors cursor-pointer"
              onClick={() => navigate("/contact")}
            >
              Contact Us
            </div>
            <div 
              className="font-medium hover:text-primary transition-colors cursor-pointer"
              onClick={() => navigate("/help")}
            >
              Help
            </div>
          </nav>
          
          {/* Cart and Mobile Menu Button */}
          <div className="flex items-center space-x-4">
            <button 
              onClick={toggleCartOpen}
              className="relative p-2"
              aria-label="Shopping Cart"
            >
              <ShoppingCart className="h-6 w-6" />
              {cartItemsCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-primary text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold">
                  {cartItemsCount}
                </span>
              )}
            </button>
            
            <button 
              onClick={() => setIsMobileMenuOpen(true)}
              className="md:hidden text-dark p-2"
              aria-label="Open mobile menu"
            >
              <Menu className="h-6 w-6" />
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile Menu */}
      <MobileMenu isOpen={isMobileMenuOpen} onClose={() => setIsMobileMenuOpen(false)} />
    </header>
  );
}
```

### client/src/pages/home.tsx
```tsx
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Helmet } from "react-helmet";
import { Button } from "@/components/ui/button";
import { ArrowRight, Award, Shield, Users, Trophy, Star } from "lucide-react";

// Define CategoryPreview interface locally
interface CategoryPreview {
  id: string;
  name: string;
  slug: string;
  image: string;
}

export default function Home() {
  const { data: categories, isLoading } = useQuery({
    queryKey: ['/api/categories'],
  });
  
  const [_, navigate] = useLocation();

  return (
    <>
      <Helmet>
        <title>Gaming Pouls - Premium Fighting Fowl</title>
        <meta name="description" content="Discover championship-quality fighting fowl with exceptional fighting skills, genetics, and breeding history." />
      </Helmet>
    
      {/* Hero Section - Enhanced with new styles */}
      <section className="hero-section">
        <div 
          className="absolute inset-0 bg-cover bg-center" 
          style={{
            backgroundImage: "url('https://pixabay.com/get/g23edd2b18a24d62d9b645106061bafce6bb26f2c6e055ec27444e7e6814bc24cbc415c226f34c6d7aa85d30d108b1ac5c1c39bf7016283b7d806186ddf7cdce8_1280.jpg')",
            opacity: 0.7
          }}
        />
        
        <div className="container mx-auto hero-content">
          <div className="max-w-2xl animate-fade-in">
            <h1 className="hero-title">Premium Gaming Pouls for Enthusiasts</h1>
            <p className="hero-description">Discover championship-quality fowl with exceptional fighting skills, genetics, and breeding history.</p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                size="lg" 
                className="btn-primary w-full"
                onClick={() => navigate("/male-pouls")}
              >
                Shop Male Pouls <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="btn-outline w-full"
                onClick={() => navigate("/female-pouls")}
              >
                Shop Female Pouls <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Heavyweight Champions Promo Section */}
      <section className="py-12 bg-gradient-to-r from-primary/10 to-secondary/10">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center gap-8">
            <div className="md:w-1/2">
              <div className="relative">
                <img 
                  src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e6/Fighting_Chicken_in_Kerala%2C_India.jpg/640px-Fighting_Chicken_in_Kerala%2C_India.jpg" 
                  alt="Heavyweight Champion Poul" 
                  className="rounded-lg shadow-xl object-cover w-full max-h-[400px]"
                />
                <div className="absolute top-4 right-4 bg-primary text-white font-bold py-2 px-4 rounded-full transform rotate-3 shadow-lg">
                  NEW ARRIVAL
                </div>
              </div>
            </div>
            <div className="md:w-1/2">
              <h2 className="text-3xl font-bold mb-4">Exclusive Heavyweight Champions</h2>
              <p className="text-lg mb-6">
                Introducing our premium collection of championship fighting pouls weighing over 3kg. These elite fighters represent the best in genetics, training, and performance.
              </p>
              <ul className="space-y-3 mb-6">
                <li className="flex items-center">
                  <span className="bg-primary/20 p-1 rounded-full mr-2">
                    <Award className="h-5 w-5 text-primary" />
                  </span>
                  <span>Premium championship bloodlines</span>
                </li>
                <li className="flex items-center">
                  <span className="bg-primary/20 p-1 rounded-full mr-2">
                    <Trophy className="h-5 w-5 text-primary" />
                  </span>
                  <span>Proven winners with verified records</span>
                </li>
                <li className="flex items-center">
                  <span className="bg-primary/20 p-1 rounded-full mr-2">
                    <Star className="h-5 w-5 text-primary" />
                  </span>
                  <span>All pouls over 3kg with exceptional strength</span>
                </li>
              </ul>
              <Button 
                size="lg" 
                className="btn-primary"
                onClick={() => navigate("/champion-pouls")}
              >
                Explore Heavyweight Champions <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Benefits */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="flex flex-col items-center text-center p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <Award className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-2">Premium Quality</h3>
              <p className="text-gray-600">Our gaming pouls are bred from championship bloodlines ensuring superior genetics.</p>
            </div>
            
            <div className="flex flex-col items-center text-center p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <Shield className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-2">Health Guarantee</h3>
              <p className="text-gray-600">All our pouls come with a health guarantee and proper vaccination records.</p>
            </div>
            
            <div className="flex flex-col items-center text-center p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <Users className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-2">Expert Support</h3>
              <p className="text-gray-600">Our team of experts is available to provide guidance on care and training.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Categories Section - Enhanced with new styles */}
      <section className="py-16 bg-accent">
        <div className="container mx-auto px-4">
          <h2 className="section-title">Browse Categories</h2>
          
          {isLoading ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
              {[...Array(5)].map((_, index) => (
                <div key={index} className="h-48 bg-gray-200 rounded-lg animate-pulse"></div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
              {Array.isArray(categories) && categories.map((category: CategoryPreview) => (
                <div 
                  key={category.id} 
                  className="product-card h-64 cursor-pointer"
                  onClick={() => navigate(`/${category.slug}`)}
                >
                  <div className="product-image">
                    <img 
                      src={category.image} 
                      alt={category.name} 
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
                  </div>
                  <div className="absolute bottom-0 left-0 p-4 w-full">
                    <h3 className="text-white font-bold text-xl mb-1">{category.name}</h3>
                    <button 
                      className="text-white text-sm flex items-center hover:underline"
                      onClick={(e) => {
                        e.stopPropagation();
                        navigate(`/${category.slug}`);
                      }}
                    >
                      View Collection <ArrowRight className="ml-1 h-3 w-3" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Admin Login Link */}
      <div className="text-center py-8 text-sm text-gray-500">
        <button 
          className="hover:text-primary transition-colors"
          onClick={() => navigate("/admin/login")}
        >
          Admin Login
        </button>
      </div>
    </>
  );
}
```

### client/src/pages/champion-pouls.tsx
```tsx
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Helmet } from "react-helmet";
import { Award, Trophy, Star } from "lucide-react";
import ProductCard from "@/components/product/product-card";
import { useCart } from "@/components/cart/cart-provider";

// Define the ChampionPoul interface
interface ChampionPoul {
  id: string;
  name: string;
  price: number;
  image: string;
  description: string;
  weight: number;
  age: number;
  wins: number;
  specialAbility: string;
  videoUrl?: string;
}

// Mock championship pouls data (over 3kg)
const championPouls: ChampionPoul[] = [
  {
    id: "cp1",
    name: "Titan Commander",
    price: 38500,
    image: "https://rurallivingtoday.com/wp-content/uploads/2018/04/fighting-birds.jpeg",
    description: "Our heavyweight champion with an impressive record of 15 wins. This 3.5kg fighter has unmatched power and strategy in the ring.",
    weight: 3.5,
    age: 3,
    wins: 15,
    specialAbility: "Knock-out power strike",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ"
  },
  {
    id: "cp2",
    name: "Supreme Warrior",
    price: 42000,
    image: "https://www.shutterstock.com/image-photo/thai-fighting-cock-farm-600nw-736520933.jpg",
    description: "A 3.8kg elite fighter known for his endurance and aggressive fighting style. Has been bred from a championship bloodline.",
    weight: 3.8,
    age: 4,
    wins: 12,
    specialAbility: "Exceptional endurance",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ"
  },
  {
    id: "cp3",
    name: "Thunder Emperor",
    price: 36000,
    image: "https://lirp.cdn-website.com/ac7cdf83/dms3rep/multi/opt/9-640w.png",
    description: "This 3.2kg champion is known for his precise and calculated attacks. Perfect for experienced trainers and serious competitions.",
    weight: 3.2,
    age: 3,
    wins: 10,
    specialAbility: "Tactical defensive strategy",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ"
  },
  {
    id: "cp4",
    name: "Colossus King",
    price: 45000,
    image: "https://cdn0.rubylane.com/_pod/item/1156352/RL-03086/Exceptional-Taxidermy-Fighting-Rooster-Cock-full-1o-720-92-f.jpg",
    description: "Our largest champion at 4.1kg with devastating power. This rare specimen commands respect with his presence alone.",
    weight: 4.1,
    age: 5,
    wins: 18,
    specialAbility: "Devastating power strikes",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ"
  },
  {
    id: "cp5",
    name: "Victory Legend",
    price: 39500,
    image: "https://www.shutterstock.com/image-photo/aseel-rooster-600nw-1196891096.jpg",
    description: "A 3.6kg champion with perfect balance of speed and power. Trained using traditional techniques passed down for generations.",
    weight: 3.6,
    age: 4,
    wins: 14,
    specialAbility: "Perfect form technique",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ"
  },
  {
    id: "cp6",
    name: "Dominator Prime",
    price: 52000,
    image: "https://upload.wikimedia.org/wikipedia/commons/thumb/e/e6/Fighting_Chicken_in_Kerala%2C_India.jpg/640px-Fighting_Chicken_in_Kerala%2C_India.jpg",
    description: "Our premium 3.9kg champion with a perfect record of 20-0. The most sought-after fighting poul for serious collectors and competitors.",
    weight: 3.9,
    age: 5,
    wins: 20,
    specialAbility: "Unbeatable instinct",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ"
  }
];

export default function ChampionPouls() {
  const [selectedChampion, setSelectedChampion] = useState<ChampionPoul | null>(null);
  const [videoDialogOpen, setVideoDialogOpen] = useState(false);
  const { addItem } = useCart();
  
  // In a real application, you would fetch this data from an API
  // For demonstration, we're using mock data
  const { data: champions = championPouls, isLoading } = useQuery({
    queryKey: ['/api/champion-pouls'],
    initialData: championPouls
  });

  const handleVideoClick = (champion: ChampionPoul) => {
    setSelectedChampion(champion);
    setVideoDialogOpen(true);
  };
  
  const handleAddToCart = (champion: ChampionPoul) => {
    addItem({
      id: champion.id,
      name: champion.name,
      price: champion.price,
      image: champion.image
    });
  };

  return (
    <>
      <Helmet>
        <title>Heavyweight Champion Pouls | Gaming Pouls</title>
        <meta name="description" content="Exclusive collection of heavyweight champion fighting pouls over 3kg. Premium genetics, proven winners, and elite bloodlines." />
      </Helmet>

      {/* Hero Section */}
      <section className="relative py-16 bg-gradient-to-r from-primary/90 to-secondary/90 text-white">
        <div className="absolute inset-0 bg-black/40 z-0"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Heavyweight Champion Pouls</h1>
            <p className="text-xl opacity-90 mb-8">
              Exclusive collection of elite fighters weighing over 3kg with proven records and exceptional genetics
            </p>
            <div className="flex flex-wrap gap-4 items-center">
              <div className="flex items-center">
                <Trophy className="h-6 w-6 text-yellow-300 mr-2" />
                <span>Competition Grade</span>
              </div>
              <div className="flex items-center">
                <Award className="h-6 w-6 text-yellow-300 mr-2" />
                <span>Championship Bloodlines</span>
              </div>
              <div className="flex items-center">
                <Star className="h-6 w-6 text-yellow-300 mr-2" />
                <span>Premium Selection</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Champion Collection Section */}
      <section className="py-16 bg-accent">
        <div className="container mx-auto px-4">
          <h2 className="section-title">Our Championship Collection</h2>
          <p className="text-center text-gray-600 max-w-3xl mx-auto mb-12">
            Each of our heavyweight champions exceeds 3kg and has been carefully selected for their superior genetics, 
            fighting prowess, and championship bloodlines. These elite fighters represent the pinnacle of quality.
          </p>
          
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[...Array(6)].map((_, index) => (
                <div key={index} className="bg-white rounded-lg overflow-hidden shadow-sm h-96 animate-pulse">
                  <div className="bg-gray-300 h-60"></div>
                  <div className="p-4">
                    <div className="h-6 bg-gray-300 rounded mb-2"></div>
                    <div className="h-4 bg-gray-200 rounded mb-3"></div>
                    <div className="h-10 bg-gray-300 rounded"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {champions.map((champion) => (
                <div key={champion.id} className="product-card overflow-hidden bg-white rounded-lg shadow-md">
                  <div className="product-image h-64 relative">
                    <img 
                      src={champion.image} 
                      alt={champion.name} 
                      className="object-cover w-full h-full"
                    />
                    <div className="absolute top-0 right-0 m-2">
                      <span className="badge">
                        {champion.weight}kg
                      </span>
                    </div>
                    {champion.videoUrl && (
                      <button 
                        className="absolute bottom-3 right-3 bg-white/80 hover:bg-white p-2 rounded-full transition-colors"
                        onClick={() => handleVideoClick(champion)}
                      >
                        <span className="sr-only">Watch video</span>
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                      </button>
                    )}
                  </div>
                  <div className="p-4">
                    <h3 className="text-xl font-bold mb-2">{champion.name}</h3>
                    <p className="product-price mb-2">₹{champion.price.toLocaleString()}</p>
                    <div className="flex flex-wrap gap-2 mb-4">
                      <span className="px-2 py-1 bg-primary/10 text-primary text-xs rounded-full">{champion.wins} Wins</span>
                      <span className="px-2 py-1 bg-primary/10 text-primary text-xs rounded-full">{champion.age} Years</span>
                      <span className="px-2 py-1 bg-secondary/10 text-secondary text-xs rounded-full">{champion.specialAbility}</span>
                    </div>
                    <p className="text-gray-600 text-sm mb-4 line-clamp-2">{champion.description}</p>
                    <button 
                      className="w-full py-2 bg-primary text-white rounded-md hover:bg-primary/90 transition-colors"
                      onClick={() => handleAddToCart(champion)}
                    >
                      Add to Cart
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Champion Quality Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="section-title">Why Choose Our Champions</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
            <div className="text-center">
              <div className="w-16 h-16 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <Trophy className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-2">Superior Genetics</h3>
              <p className="text-gray-600">
                Our heavyweight champions come from carefully selected bloodlines that have been perfected over generations for optimal performance.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <Award className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-2">Proven Winners</h3>
              <p className="text-gray-600">
                Every champion in our collection has a verified track record of wins in competition, ensuring you receive a proven fighter.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <Star className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-2">Elite Training</h3>
              <p className="text-gray-600">
                Our champions undergo rigorous training programs to develop their natural abilities and fighting techniques.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Video Dialog for champion videos */}
      {selectedChampion && (
        <div className={`fixed inset-0 z-50 flex items-center justify-center ${videoDialogOpen ? 'block' : 'hidden'}`}>
          <div className="absolute inset-0 bg-black/70" onClick={() => setVideoDialogOpen(false)}></div>
          <div className="relative bg-white rounded-lg overflow-hidden max-w-4xl w-full mx-4">
            <div className="p-4 border-b flex justify-between items-center">
              <h3 className="font-bold text-lg">{selectedChampion.name} - Fighting Demonstration</h3>
              <button onClick={() => setVideoDialogOpen(false)} className="text-gray-500 hover:text-gray-700">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            <div className="aspect-video">
              {selectedChampion.videoUrl && (
                <iframe
                  width="100%"
                  height="100%"
                  src={selectedChampion.videoUrl}
                  title="Champion Video"
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                ></iframe>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
```

### client/src/pages/admin/login.tsx
```tsx
import { useState } from "react";
import { useLocation } from "wouter";
import { Helmet } from "react-helmet";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { AlertCircle, Lock } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";

const loginFormSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

type LoginFormValues = z.infer<typeof loginFormSchema>;

export default function AdminLogin() {
  const [_, navigate] = useLocation();
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  // Predefined admin credentials
  const ADMIN_EMAIL = "kondurusiva01@gmail.com";
  const ADMIN_PASSWORD = "siva1234";

  const form = useForm<LoginFormValues>({
    resolver: zodResolver(loginFormSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  const onSubmit = async (data: LoginFormValues) => {
    setIsLoading(true);
    setError(null);
    
    // Simple client-side verification for demo purposes
    // In a real application, this would be a server API call
    if (data.email === ADMIN_EMAIL && data.password === ADMIN_PASSWORD) {
      // Store admin session in localStorage
      localStorage.setItem("adminAuthenticated", "true");
      localStorage.setItem("adminEmail", data.email);
      
      // Show success message
      toast({
        title: "Login successful",
        description: "Welcome to the admin dashboard",
      });
      
      // Redirect to admin dashboard
      setTimeout(() => {
        navigate("/admin/dashboard");
      }, 1000);
    } else {
      setError("Invalid email or password. Please try again.");
    }
    
    setIsLoading(false);
  };

  return (
    <>
      <Helmet>
        <title>Admin Login | Gaming Pouls</title>
        <meta name="description" content="Admin login for Gaming Pouls e-commerce platform." />
      </Helmet>

      <div className="min-h-screen flex items-center justify-center bg-accent">
        <div className="w-full max-w-md p-8 bg-white rounded-lg shadow-lg animate-fade-in">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-primary/10 rounded-full mx-auto flex items-center justify-center mb-4">
              <Lock className="h-8 w-8 text-primary" />
            </div>
            <h1 className="text-2xl font-bold">Admin Login</h1>
            <p className="text-gray-600 mt-2">Enter your credentials to access the admin dashboard</p>
          </div>

          {error && (
            <Alert variant="destructive" className="mb-6">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="admin@example.com" 
                        type="email" 
                        {...field} 
                        autoComplete="email" 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Password</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="••••••••" 
                        type="password" 
                        {...field} 
                        autoComplete="current-password" 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button 
                type="submit" 
                className="w-full bg-primary hover:bg-primary/90" 
                disabled={isLoading}
              >
                {isLoading ? "Logging in..." : "Login"}
              </Button>
            </form>
          </Form>

          <div className="mt-6 text-center">
            <button 
              className="text-sm text-gray-600 hover:text-primary transition-colors"
              onClick={() => navigate("/")}
            >
              Back to Home
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
```

### client/src/index.css
```css
@tailwind base;
@tailwind components;
@tailwind utilities;

:root {
  --background: 140 23% 97%;
  --foreground: 20 14.3% 4.1%;
  --muted: 60 4.8% 95.9%;
  --muted-foreground: 25 5.3% 44.7%;
  --popover: 0 0% 100%;
  --popover-foreground: 20 14.3% 4.1%;
  --card: 0 0% 100%;
  --card-foreground: 20 14.3% 4.1%;
  --border: 20 5.9% 90%;
  --input: 20 5.9% 90%;
  --primary: 16 95% 60%;
  --primary-foreground: 0 0% 100%;
  --secondary: 173 73% 45%;
  --secondary-foreground: 0 0% 100%;
  --accent: 140 23% 97%;
  --accent-foreground: 24 9.8% 10%;
  --destructive: 0 84.2% 60.2%;
  --destructive-foreground: 60 9.1% 97.8%;
  --ring: 20 14.3% 4.1%;
  --radius: 0.5rem;
}

.dark {
  --background: 240 10% 3.9%;
  --foreground: 0 0% 98%;
  --muted: 240 3.7% 15.9%;
  --muted-foreground: 240 5% 64.9%;
  --popover: 240 10% 3.9%;
  --popover-foreground: 0 0% 98%;
  --card: 240 10% 3.9%;
  --card-foreground: 0 0% 98%;
  --border: 240 3.7% 15.9%;
  --input: 240 3.7% 15.9%;
  --primary: 16 95% 60%;
  --primary-foreground: 0 0% 100%;
  --secondary: 173 73% 45%;
  --secondary-foreground: 0 0% 100%;
  --accent: 240 3.7% 15.9%;
  --accent-foreground: 0 0% 98%;
  --destructive: 0 62.8% 30.6%;
  --destructive-foreground: 0 0% 98%;
  --ring: 240 4.9% 83.9%;
}

@layer base {
  * {
    @apply border-border;
  }

  body {
    @apply font-sans antialiased bg-background text-foreground;
  }
  
  h1, h2, h3, h4, h5 {
    @apply font-bold tracking-tight;
  }
  
  h1 {
    @apply text-4xl md:text-5xl lg:text-6xl;
  }
  
  h2 {
    @apply text-3xl md:text-4xl;
  }
  
  h3 {
    @apply text-2xl md:text-3xl;
  }
}

/* Enhanced Product Card */
.product-card {
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;
  @apply rounded-lg shadow-sm hover:shadow-md;
}

.product-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
}

.product-card .badge {
  @apply absolute top-3 right-3 z-10 px-2 py-1 text-xs font-semibold rounded-full;
  background: linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(var(--secondary)) 100%);
  color: white;
  transform: rotate(3deg);
}

.product-card .product-image {
  @apply relative overflow-hidden;
  aspect-ratio: 1 / 1;
}

.product-card .product-image img {
  @apply w-full h-full object-cover transition-transform duration-500 ease-in-out;
}

.product-card:hover .product-image img {
  transform: scale(1.05);
}

.product-card .product-content {
  @apply p-4;
}

.product-card .product-price {
  @apply text-xl font-bold text-primary;
  background: linear-gradient(135deg, hsl(var(--primary)), hsl(var(--secondary)));
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  display: inline-block;
}

/* Cart Count Badge */
.cart-count {
  position: absolute;
  top: -8px;
  right: -8px;
  @apply bg-primary text-white rounded-full w-5 h-5 text-xs flex items-center justify-center font-bold;
  box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
}

/* Hero Section Styles */
.hero-section {
  background: linear-gradient(135deg, hsl(var(--primary)/0.9), hsl(var(--secondary)/0.9));
  @apply relative overflow-hidden;
}

.hero-section::before {
  content: '';
  @apply absolute inset-0 bg-black/50;
  z-index: 0;
}

.hero-content {
  @apply relative z-10 py-24 md:py-32 px-4;
}

.hero-title {
  @apply text-4xl md:text-5xl lg:text-6xl font-extrabold text-white mb-4;
  text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
}

.hero-description {
  @apply text-xl text-white/90 max-w-xl mb-8;
  text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.3);
}

/* Button Styles */
.btn-primary {
  @apply bg-primary text-white hover:bg-primary/90 font-medium py-2 px-6 rounded-md transition duration-300;
  box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
}

.btn-secondary {
  @apply bg-white text-primary hover:bg-gray-50 border border-primary font-medium py-2 px-6 rounded-md transition duration-300;
  box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
}

.btn-outline {
  @apply bg-transparent text-white hover:bg-white/20 border border-white font-medium py-2 px-6 rounded-md transition duration-300;
}

/* Utility classes */
.section-title {
  @apply text-3xl font-bold mb-8 text-center;
  position: relative;
  padding-bottom: 0.5rem;
}

.section-title::after {
  content: '';
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 80px;
  height: 3px;
  @apply bg-primary rounded-full;
}

/* Admin styles */
.admin-sidebar {
  @apply w-64 bg-white h-screen border-r fixed left-0 top-0 shadow-sm;
  z-index: 40;
}

.admin-content {
  @apply ml-64 p-6;
}

.admin-header {
  @apply bg-white border-b py-4 px-6 flex items-center justify-between;
  position: sticky;
  top: 0;
  z-index: 30;
}

.admin-menu-item {
  @apply flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-gray-100 transition-colors;
}

.admin-menu-item.active {
  @apply bg-primary/10 text-primary font-medium border-r-4 border-primary;
}

/* Animations */
@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

.animate-fade-in {
  animation: fadeIn 0.5s ease-in-out;
}

/* Responsive adjustments */
@media (max-width: 640px) {
  .container {
    @apply px-4;
  }
  
  .section-title {
    @apply text-2xl;
  }
  
  .admin-sidebar {
    transform: translateX(-100%);
    transition: transform 0.3s ease;
  }
  
  .admin-sidebar.open {
    transform: translateX(0);
  }
  
  .admin-content {
    @apply ml-0;
  }
}
```

## Server Files

### server/routes.ts
```typescript
import { Express, Request, Response } from "express";
import { Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // Categories endpoint
  app.get("/api/categories", async (req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      console.error("Error fetching categories:", error);
      res.status(500).json({ error: "Failed to fetch categories" });
    }
  });

  // Male Pouls endpoint
  app.get("/api/male-pouls", async (req, res) => {
    try {
      const { fightingSkill, weightRange, sortBy } = req.query;
      const malePouls = await storage.getMalePouls(
        fightingSkill as string,
        weightRange as string,
        sortBy as string
      );
      res.json(malePouls);
    } catch (error) {
      console.error("Error fetching male pouls:", error);
      res.status(500).json({ error: "Failed to fetch male pouls" });
    }
  });

  // Female Pouls endpoint
  app.get("/api/female-pouls", async (req, res) => {
    try {
      const { geneticsQuality, eggProduction, sortBy } = req.query;
      const femalePouls = await storage.getFemalePouls(
        geneticsQuality as string,
        eggProduction as string,
        sortBy as string
      );
      res.json(femalePouls);
    } catch (error) {
      console.error("Error fetching female pouls:", error);
      res.status(500).json({ error: "Failed to fetch female pouls" });
    }
  });

  // Egg Clusters endpoint
  app.get("/api/egg-clusters", async (req, res) => {
    try {
      const eggClusters = await storage.getEggClusters();
      res.json(eggClusters);
    } catch (error) {
      console.error("Error fetching egg clusters:", error);
      res.status(500).json({ error: "Failed to fetch egg clusters" });
    }
  });

  // Village Products endpoint
  app.get("/api/village-products", async (req, res) => {
    try {
      const villageProducts = await storage.getVillageProducts();
      res.json(villageProducts);
    } catch (error) {
      console.error("Error fetching village products:", error);
      res.status(500).json({ error: "Failed to fetch village products" });
    }
  });

  // Chicks endpoint
  app.get("/api/chicks", async (req, res) => {
    try {
      const { ageFilter, sortBy } = req.query;
      const chicks = await storage.getChicks(
        ageFilter as string,
        sortBy as string
      );
      res.json(chicks);
    } catch (error) {
      console.error("Error fetching chicks:", error);
      res.status(500).json({ error: "Failed to fetch chicks" });
    }
  });

  // Contact form endpoint
  app.post("/api/contact", async (req, res) => {
    try {
      const contact = await storage.createContact(req.body);
      res.status(201).json(contact);
    } catch (error) {
      console.error("Error creating contact:", error);
      res.status(500).json({ error: "Failed to submit contact form" });
    }
  });

  // Order endpoint
  app.post("/api/orders", async (req, res) => {
    try {
      const order = await storage.createOrder(req.body);
      res.status(201).json(order);
    } catch (error) {
      console.error("Error creating order:", error);
      res.status(500).json({ error: "Failed to create order" });
    }
  });

  // Create HTTP server
  const httpServer = require("http").createServer(app);

  return httpServer;
}
```

### server/storage.ts
```typescript
import {
  User,
  InsertUser,
  Contact,
  InsertContact,
  Order,
  InsertOrder,
  CategoryPreview,
  MalePoul,
  FemalePoul,
  EggCluster,
  VillageHen,
  VillageEgg,
  Chick
} from "@/shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getCategories(): Promise<CategoryPreview[]>;
  getMalePouls(fightingSkill?: string, weightRange?: string, sortBy?: string): Promise<MalePoul[]>;
  getFemalePouls(geneticsQuality?: string, eggProduction?: string, sortBy?: string): Promise<FemalePoul[]>;
  getEggClusters(): Promise<EggCluster[]>;
  getVillageProducts(): Promise<{ hen: VillageHen; egg: VillageEgg }>;
  getChicks(ageFilter?: string, sortBy?: string): Promise<Chick[]>;
  createContact(contact: InsertContact): Promise<Contact>;
  createOrder(order: InsertOrder): Promise<Order>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private contacts: Map<number, Contact>;
  private orders: Map<number, Order>;
  private categories: CategoryPreview[];
  private malePouls: MalePoul[];
  private femalePouls: FemalePoul[];
  private eggClusters: EggCluster[];
  private villageHen: VillageHen;
  private villageEgg: VillageEgg;
  private chicks: Chick[];

  private userCurrentId: number;
  private contactCurrentId: number;
  private orderCurrentId: number;

  constructor() {
    this.users = new Map();
    this.contacts = new Map();
    this.orders = new Map();
    
    this.userCurrentId = 1;
    this.contactCurrentId = 1;
    this.orderCurrentId = 1;
    
    this.initializeProductData();
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    for (const user of this.users.values()) {
      if (user.username === username) {
        return user;
      }
    }
    return undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getCategories(): Promise<CategoryPreview[]> {
    return this.categories;
  }

  async getMalePouls(fightingSkill?: string, weightRange?: string, sortBy?: string): Promise<MalePoul[]> {
    let filteredPouls = [...this.malePouls];
    
    // Apply filters
    if (fightingSkill && fightingSkill !== "all-levels") {
      filteredPouls = filteredPouls.filter(poul => poul.skillLevel.toLowerCase() === fightingSkill);
    }
    
    if (weightRange && weightRange !== "all-weights") {
      if (weightRange === "lightweight") {
        filteredPouls = filteredPouls.filter(poul => poul.weight >= 1.5 && poul.weight < 2.0);
      } else if (weightRange === "middleweight") {
        filteredPouls = filteredPouls.filter(poul => poul.weight >= 2.0 && poul.weight < 2.5);
      } else if (weightRange === "heavyweight") {
        filteredPouls = filteredPouls.filter(poul => poul.weight >= 2.5);
      }
    }
    
    // Apply sorting
    if (sortBy) {
      if (sortBy === "price-low") {
        filteredPouls.sort((a, b) => a.price - b.price);
      } else if (sortBy === "price-high") {
        filteredPouls.sort((a, b) => b.price - a.price);
      } else if (sortBy === "skill-high") {
        const skillOrder = {"beginner": 1, "intermediate": 2, "advanced": 3, "pro": 4};
        filteredPouls.sort((a, b) => 
          skillOrder[b.skillLevel.toLowerCase() as keyof typeof skillOrder] - 
          skillOrder[a.skillLevel.toLowerCase() as keyof typeof skillOrder]
        );
      } else if (sortBy === "wins") {
        filteredPouls.sort((a, b) => b.wins - a.wins);
      }
    }
    
    return filteredPouls;
  }

  async getFemalePouls(geneticsQuality?: string, eggProduction?: string, sortBy?: string): Promise<FemalePoul[]> {
    let filteredPouls = [...this.femalePouls];
    
    // Apply filters
    if (geneticsQuality && geneticsQuality !== "all") {
      filteredPouls = filteredPouls.filter(poul => 
        poul.geneticsQuality.toLowerCase() === geneticsQuality
      );
    }
    
    if (eggProduction && eggProduction !== "all") {
      if (eggProduction === "high") {
        filteredPouls = filteredPouls.filter(poul => poul.eggsPerWeek >= 5);
      } else if (eggProduction === "medium") {
        filteredPouls = filteredPouls.filter(poul => poul.eggsPerWeek >= 3 && poul.eggsPerWeek < 5);
      } else if (eggProduction === "low") {
        filteredPouls = filteredPouls.filter(poul => poul.eggsPerWeek < 3);
      }
    }
    
    // Apply sorting
    if (sortBy) {
      if (sortBy === "price-low") {
        filteredPouls.sort((a, b) => a.price - b.price);
      } else if (sortBy === "price-high") {
        filteredPouls.sort((a, b) => b.price - a.price);
      } else if (sortBy === "egg-production") {
        filteredPouls.sort((a, b) => b.eggsPerWeek - a.eggsPerWeek);
      } else if (sortBy === "genetics") {
        const qualityOrder = {"standard": 1, "premium": 2, "elite": 3};
        filteredPouls.sort((a, b) => 
          qualityOrder[b.geneticsQuality.toLowerCase() as keyof typeof qualityOrder] - 
          qualityOrder[a.geneticsQuality.toLowerCase() as keyof typeof qualityOrder]
        );
      }
    }
    
    return filteredPouls;
  }

  async getEggClusters(): Promise<EggCluster[]> {
    return this.eggClusters;
  }

  async getVillageProducts(): Promise<{ hen: VillageHen; egg: VillageEgg }> {
    return {
      hen: this.villageHen,
      egg: this.villageEgg
    };
  }

  async getChicks(ageFilter?: string, sortBy?: string): Promise<Chick[]> {
    let filteredChicks = [...this.chicks];
    
    // Apply age filter
    if (ageFilter && ageFilter !== "all-ages") {
      if (ageFilter === "1month") {
        filteredChicks = filteredChicks.filter(chick => chick.ageInMonths === 1);
      } else if (ageFilter === "2months") {
        filteredChicks = filteredChicks.filter(chick => chick.ageInMonths === 2);
      } else if (ageFilter === "3months") {
        filteredChicks = filteredChicks.filter(chick => chick.ageInMonths === 3);
      } else if (ageFilter === "4plusmonths") {
        filteredChicks = filteredChicks.filter(chick => chick.ageInMonths >= 4);
      }
    }
    
    // Apply sorting
    if (sortBy) {
      if (sortBy === "price-low") {
        filteredChicks.sort((a, b) => a.price - b.price);
      } else if (sortBy === "price-high") {
        filteredChicks.sort((a, b) => b.price - a.price);
      } else if (sortBy === "age-young") {
        filteredChicks.sort((a, b) => a.ageInMonths - b.ageInMonths);
      } else if (sortBy === "age-old") {
        filteredChicks.sort((a, b) => b.ageInMonths - a.ageInMonths);
      }
    }
    
    return filteredChicks;
  }

  async createContact(contactData: InsertContact): Promise<Contact> {
    const id = this.contactCurrentId++;
    const contact: Contact = {
      ...contactData,
      id,
      createdAt: new Date(),
    };
    this.contacts.set(id, contact);
    return contact;
  }

  async createOrder(orderData: InsertOrder): Promise<Order> {
    const id = this.orderCurrentId++;
    const order: Order = {
      ...orderData,
      id,
      createdAt: new Date(),
      status: "pending"
    };
    this.orders.set(id, order);
    return order;
  }

  private initializeProductData() {
    // Initialize categories
    this.categories = [
      {
        id: "1",
        name: "Male Pouls",
        slug: "male-pouls",
        image: "https://media.istockphoto.com/id/1214366766/photo/beautiful-fighting-cock.jpg?s=612x612&w=0&k=20&c=iyHhnJwHz_Q5MfYlcCX11sytGGNnGnAoMZ__WSXGIXc="
      },
      {
        id: "2",
        name: "Female Pouls",
        slug: "female-pouls",
        image: "https://media.istockphoto.com/id/119917493/photo/bantam-chicken.jpg?s=612x612&w=0&k=20&c=bHORojXJoRiOjYwXYJ0gxCEZxMlBK_OcdoCoUnDynO0="
      },
      {
        id: "3",
        name: "Egg Clusters",
        slug: "egg-clusters",
        image: "https://media.istockphoto.com/id/1349983113/photo/fresh-chicken-and-quail-eggs-are-scattered-on-a-wooden-rustic-table-selective-focus.jpg?s=612x612&w=0&k=20&c=hzfR8NtKmMsmSOVsp23A2rFLhvpKQee2CKnB2vIkzQc="
      },
      {
        id: "4",
        name: "Village Hens",
        slug: "village-hens",
        image: "https://media.istockphoto.com/id/183413000/photo/country-chicken.jpg?s=612x612&w=0&k=20&c=PXL8f7_0qh6_jfBFLXR88rYwILhUO0nalY0I0lPDYAA="
      },
      {
        id: "5",
        name: "Chicks",
        slug: "chicks",
        image: "https://media.istockphoto.com/id/1293388093/photo/the-chick-or-chicken-sit-on-wood-the-baby-bird-from-farm-beautiful-and-cute-animal.jpg?s=612x612&w=0&k=20&c=fppzR8th3qP1UkWDG_F6Lg8tNY7YAZQKnIpdwHrjPZA="
      }
    ];
    
    // Initialize Male Pouls
    this.malePouls = [
      {
        id: "mp1",
        name: "Red Warrior",
        price: 8500,
        image: "https://media.istockphoto.com/id/1214366766/photo/beautiful-fighting-cock.jpg?s=612x612&w=0&k=20&c=iyHhnJwHz_Q5MfYlcCX11sytGGNnGnAoMZ__WSXGIXc=",
        description: "A powerful male poul with exceptional fighting skills. Well-trained and ready for competition.",
        skillLevel: "Advanced",
        weight: 2.3,
        age: 2,
        wins: 7,
        videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ"
      },
      {
        id: "mp2",
        name: "Black Thunder",
        price: 7200,
        image: "https://media.istockphoto.com/id/1322193285/photo/beautiful-fighting-cock.jpg?s=612x612&w=0&k=20&c=TKNqY8-_Fn3BCGWRDRio-dH9LgcKI-KqxLCMR_cYV8U=",
        description: "A nimble and agile male poul known for its speed and precision in fights.",
        skillLevel: "Intermediate",
        weight: 2.1,
        age: 1.5,
        wins: 4
      },
      {
        id: "mp3",
        name: "Golden Champion",
        price: 12000,
        image: "https://media.istockphoto.com/id/1413454747/photo/the-beautiful-gamecock.jpg?s=612x612&w=0&k=20&c=NhWZgUEXGAkH1mJZ_vrGzw6qTv22QjWZTH9NJZZtxZM=",
        description: "A premium male poul with champion bloodline. Has won several major competitions.",
        skillLevel: "Pro",
        weight: 2.7,
        age: 3,
        wins: 12,
        videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ"
      },
      {
        id: "mp4",
        name: "Fighting Spirit",
        price: 6500,
        image: "https://media.istockphoto.com/id/1295974731/photo/fighting-cock-in-arena.jpg?s=612x612&w=0&k=20&c=QyLtfnVL1BaKnG4HlFEs9mqKgOU5G8Q8FwYe6aIMh7Q=",
        description: "A young male poul with great potential. Perfect for training and future competitions.",
        skillLevel: "Beginner",
        weight: 1.9,
        age: 1,
        wins: 1
      },
      {
        id: "mp5",
        name: "Silver Striker",
        price: 9200,
        image: "https://media.istockphoto.com/id/1367895172/photo/a-beautiful-chicken-on-the-farm.jpg?s=612x612&w=0&k=20&c=yGDAjzVpVFbY5bFNqVNuS8hZDleTkRvjgVZTWC0J-GI=",
        description: "A unique silver-feathered male poul with excellent fighting techniques and stamina.",
        skillLevel: "Advanced",
        weight: 2.4,
        age: 2.5,
        wins: 8,
        videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ"
      },
      {
        id: "mp6",
        name: "Supreme Fighter",
        price: 15000,
        image: "https://media.istockphoto.com/id/1448390450/photo/chicken-rooster-in-nature.jpg?s=612x612&w=0&k=20&c=lqp-y9ic0R7cZglScMyfGZdbNfJk8Y-zdAHgXCLPDac=",
        description: "Our top-tier male poul with impeccable genetics and training. The ultimate competition fowl.",
        skillLevel: "Pro",
        weight: 2.8,
        age: 3.5,
        wins: 15,
        videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ"
      }
    ];
    
    // Initialize Female Pouls
    this.femalePouls = [
      {
        id: "fp1",
        name: "Red Queen",
        price: 6500,
        image: "https://media.istockphoto.com/id/1446011651/photo/chicken-on-a-farm.jpg?s=612x612&w=0&k=20&c=OCdl2L73ixYYCW6aVGMn8bQ4K6y4IwEJa2urN6hO9zs=",
        description: "A beautiful female poul with excellent breeding capabilities. Produces strong offspring.",
        geneticsQuality: "Premium",
        weight: 1.8,
        age: 2,
        eggsPerWeek: 4,
        eggPrice: 120
      },
      {
        id: "fp2",
        name: "Gold Layer",
        price: 5800,
        image: "https://media.istockphoto.com/id/537450789/photo/hen-isolated-on-white.jpg?s=612x612&w=0&k=20&c=y8aZ5EyxJPKNLYiiiTyXw2cAxrQTMHBwV7oe8hdqKmQ=",
        description: "A highly productive female poul that lays eggs consistently. Great for egg production.",
        geneticsQuality: "Standard",
        weight: 1.7,
        age: 1.5,
        eggsPerWeek: 6,
        eggPrice: 100
      },
      {
        id: "fp3",
        name: "Royal Breeder",
        price: 9000,
        image: "https://media.istockphoto.com/id/153713248/photo/white-hen-with-black-spots.jpg?s=612x612&w=0&k=20&c=JXCHDdlQgXN-v_3jfkUglWe_AqQ9Gp0jG8PaSIjQ-OI=",
        description: "Our top breeding female with exceptional genetics. Produces champion-quality offspring.",
        geneticsQuality: "Elite",
        weight: 2.1,
        age: 3,
        eggsPerWeek: 3,
        eggPrice: 200
      },
      {
        id: "fp4",
        name: "Silver Beauty",
        price: 4900,
        image: "https://media.istockphoto.com/id/889391598/photo/brahma-chicken-isolated-on-a-white-background.jpg?s=612x612&w=0&k=20&c=BxdQHJVUcSN31tB15tJEkSWXd5OgLaYKWBL6eDEPhhI=",
        description: "A young female poul with good breeding potential. Ideal for beginners in breeding.",
        geneticsQuality: "Standard",
        weight: 1.6,
        age: 1,
        eggsPerWeek: 5,
        eggPrice: 90
      },
      {
        id: "fp5",
        name: "Premium Breeder",
        price: 7500,
        image: "https://media.istockphoto.com/id/183413003/photo/hen.jpg?s=612x612&w=0&k=20&c=F2AxOQNJMN_qAwEkiAT8rHqLNHjZZXGBNdFM1F6Lseo=",
        description: "A mature female poul with proven breeding record. Consistently produces quality offspring.",
        geneticsQuality: "Premium",
        weight: 2.0,
        age: 2.5,
        eggsPerWeek: 4,
        eggPrice: 150
      }
    ];
    
    // Initialize Egg Clusters
    this.eggClusters = [
      {
        id: "ec1",
        name: "Single Egg (1-on-1)",
        count: 1,
        price: 200,
        image: "https://media.istockphoto.com/id/1405010344/photo/fresh-farm-egg-isolated-on-white-background.jpg?s=612x612&w=0&k=20&c=6-1aXnBmP-dUm1aD6sdMfEQqXH93VPXcHrXi2A6wASs=",
        description: "A single premium egg from our champion pouls. Ideal for specific breeding projects.",
        isBestValue: false
      },
      {
        id: "ec2",
        name: "Small Cluster (5 Eggs)",
        count: 5,
        price: 850,
        image: "https://media.istockphoto.com/id/167125638/photo/five-brown-eggs.jpg?s=612x612&w=0&k=20&c=0BMmVZfPGCxi8RMTDt5z4Olq5sCuEW1TrGr1zE_Fvwc=",
        description: "A small cluster of 5 premium eggs. Perfect for small-scale breeding.",
        isBestValue: false
      },
      {
        id: "ec3",
        name: "Medium Cluster (10 Eggs)",
        count: 10,
        price: 1500,
        image: "https://media.istockphoto.com/id/172176581/photo/egg-carton.jpg?s=612x612&w=0&k=20&c=YZSCaJnlvC7wvPhWCTqxZLcLxJ-0_iLQ8LfEXJCZ72g=",
        description: "A medium cluster of 10 premium eggs. Great value for regular breeders.",
        isBestValue: true
      },
      {
        id: "ec4",
        name: "Large Cluster (20 Eggs)",
        count: 20,
        price: 2800,
        image: "https://media.istockphoto.com/id/499369224/photo/egg-carton.jpg?s=612x612&w=0&k=20&c=OY_7yrTvw0foJZh67SswUBr48fyXCJ4ZR9YaxZMz-1s=",
        description: "A large cluster of 20 premium eggs. Ideal for commercial breeding operations.",
        isBestValue: false
      },
      {
        id: "ec5",
        name: "Champion Bloodline Cluster (5 Eggs)",
        count: 5,
        price: 1200,
        image: "https://media.istockphoto.com/id/91696728/photo/egg-carton.jpg?s=612x612&w=0&k=20&c=Y6gXt3vBj2ODGvVUzBGQoDTSisZPChaF6tMfLFpogm0=",
        description: "A special cluster of 5 eggs from our champion bloodline pouls. Premium genetics guaranteed.",
        isBestValue: false
      }
    ];
    
    // Initialize Village Products
    this.villageHen = {
      id: "vh1",
      name: "Village Hen",
      description: "Organic and free-range village hens raised in natural conditions. Perfect for traditional cooking.",
      pricePerKg: 350,
      image: "https://media.istockphoto.com/id/1367883391/photo/colorful-rooster-or-fighting-cock-in-white-background.jpg?s=612x612&w=0&k=20&c=hCf-5Sx9qwGIGxYV3KM9Vo8dhqO5pmBiK0nwM3LfkGw="
    };
    
    this.villageEgg = {
      id: "ve1",
      name: "Village Egg",
      description: "Fresh, organic eggs from our free-range village hens. Rich in nutrients and flavor.",
      pricePerEgg: 25,
      image: "https://media.istockphoto.com/id/505422600/photo/egg.jpg?s=612x612&w=0&k=20&c=40aYbj-7RWIDWy-7O_D_be9l2OHxdVYjT6c-9jG8zg8="
    };
    
    // Initialize Chicks
    this.chicks = [
      {
        id: "ch1",
        name: "1-Month Chick",
        ageInMonths: 1,
        ageDisplay: "1 Month",
        weight: 0.3,
        price: 1200,
        image: "https://media.istockphoto.com/id/1293388093/photo/the-chick-or-chicken-sit-on-wood-the-baby-bird-from-farm-beautiful-and-cute-animal.jpg?s=612x612&w=0&k=20&c=fppzR8th3qP1UkWDG_F6Lg8tNY7YAZQKnIpdwHrjPZA=",
        description: "A healthy 1-month-old chick from our premium bloodlines. Great potential for training."
      },
      {
        id: "ch2",
        name: "2-Month Chick",
        ageInMonths: 2,
        ageDisplay: "2 Months",
        weight: 0.6,
        price: 1800,
        image: "https://media.istockphoto.com/id/1366475367/photo/golden-brown-baby-chick-on-a-white-wooden-table.jpg?s=612x612&w=0&k=20&c=33CKXbljVvjTZQu--vDSQKIUEZSGh-_D0A2BVdnaDgo=",
        description: "A well-developed 2-month-old chick showing good growth and characteristics."
      },
      {
        id: "ch3",
        name: "3-Month Chick",
        ageInMonths: 3,
        ageDisplay: "3 Months",
        weight: 1.0,
        price: 2500,
        image: "https://media.istockphoto.com/id/1339087854/photo/cute-chick-isolated-on-white.jpg?s=612x612&w=0&k=20&c=8mIKC3o-dWQ-r7CYfP9EjDZ8hT2jLeSeyaWM0gQ-lO4=",
        description: "A strong 3-month-old chick beginning to show adult characteristics. Ready for specialized training."
      },
      {
        id: "ch4",
        name: "4-Month Chick",
        ageInMonths: 4,
        ageDisplay: "4 Months",
        weight: 1.5,
        price: 3200,
        image: "https://media.istockphoto.com/id/1352041329/photo/red-junglefowl-on-a-vintage-wooden-chair.jpg?s=612x612&w=0&k=20&c=3MbVgxZCNZROGjCaIk4BT8a1fUdZ7a6-ZiqSJYEA8xs=",
        description: "A nearly mature 4-month-old chick showing excellent development. Ready for advanced training."
      },
      {
        id: "ch5",
        name: "Premium Bloodline Chick",
        ageInMonths: 2,
        ageDisplay: "2 Months (Premium)",
        weight: 0.7,
        price: 3000,
        image: "https://media.istockphoto.com/id/1359474627/photo/hen-little-chicken-on-the-nature.jpg?s=612x612&w=0&k=20&c=lhekx59SZjdhdgF3yk5ST_Jm6RCZhQI-lXIYRE_m1YE=",
        description: "A special 2-month-old chick from our champion bloodlines. Exceptional genetics and potential."
      }
    ];
  }
}

export const storage = new MemStorage();
```

### shared/schema.ts
```typescript
import { z } from "zod";
import {
  pgTable,
  serial,
  text,
  varchar,
  timestamp,
  integer,
  boolean,
  doublePrecision,
  json,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";

// Product Table
export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  price: integer("price").notNull(),
  categoryId: integer("category_id").notNull(),
  image: varchar("image", { length: 255 }),
  stock: integer("stock").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertProductSchema = createInsertSchema(products).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertProduct = z.infer<typeof insertProductSchema>;
export type Product = typeof products.$inferSelect;

// Category Table
export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  image: varchar("image", { length: 255 }),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertCategorySchema = createInsertSchema(categories).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertCategory = z.infer<typeof insertCategorySchema>;
export type Category = typeof categories.$inferSelect;

// Order Table
export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  items: json("items").notNull(),
  total: integer("total").notNull(),
  status: varchar("status", { length: 50 }).notNull(),
  shippingAddress: json("shipping_address"),
  paymentMethod: varchar("payment_method", { length: 50 }),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertOrderSchema = createInsertSchema(orders).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  status: true,
});

export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type Order = typeof orders.$inferSelect;

// Contact Table
export const contacts = pgTable("contacts", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 255 }).notNull(),
  phone: varchar("phone", { length: 50 }),
  message: text("message").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertContactSchema = createInsertSchema(contacts).omit({
  id: true,
  createdAt: true,
});

export type InsertContact = z.infer<typeof insertContactSchema>;
export type Contact = typeof contacts.$inferSelect;

// User Table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: varchar("username", { length: 50 }).notNull().unique(),
  password: varchar("password", { length: 255 }).notNull(),
  email: varchar("email", { length: 255 }).unique(),
  phone: varchar("phone", { length: 50 }),
  address: json("address"),
  role: varchar("role", { length: 20 }).default("customer"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  phone: true,
  address: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Interface definitions for the in-memory store
export interface CategoryPreview {
  id: string;
  name: string;
  slug: string;
  image: string;
}

export interface MalePoul {
  id: string;
  name: string;
  price: number;
  image: string;
  description: string;
  skillLevel: string;
  weight: number;
  age: number;
  wins: number;
  videoUrl?: string;
}

export interface FemalePoul {
  id: string;
  name: string;
  price: number;
  image: string;
  description: string;
  geneticsQuality: string;
  weight: number;
  age: number;
  eggsPerWeek: number;
  eggPrice: number;
}

export interface EggCluster {
  id: string;
  name: string;
  count: number;
  price: number;
  image: string;
  description: string;
  isBestValue: boolean;
}

export interface VillageHen {
  id: string;
  name: string;
  description: string;
  pricePerKg: number;
  image: string;
}

export interface VillageEgg {
  id: string;
  name: string;
  description: string;
  pricePerEgg: number;
  image: string;
}

export interface Chick {
  id: string;
  name: string;
  ageInMonths: number;
  ageDisplay: string;
  weight: number;
  price: number;
  image: string;
  description: string;
}

export interface ContactFormData {
  name: string;
  email: string;
  phone?: string;
  message: string;
}
```

Hope this helps! All the code is now organized in one document for your reference. The website is focused exclusively on pouls/hens as requested, with special emphasis on heavyweight champion pouls over 3kg.