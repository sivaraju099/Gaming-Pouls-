import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { insertContactSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get Categories
  app.get("/api/categories", async (_req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  // Get Male Pouls with optional filters
  app.get("/api/male-pouls", async (req, res) => {
    try {
      const { fightingSkill, weightRange, sortBy } = req.query;
      const malePouls = await storage.getMalePouls(
        fightingSkill as string,
        weightRange as string,
        sortBy as string
      );
      res.json(malePouls);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch male pouls" });
    }
  });

  // Get Female Pouls with optional filters
  app.get("/api/female-pouls", async (req, res) => {
    try {
      const { geneticsQuality, eggProduction, sortBy } = req.query;
      const femalePouls = await storage.getFemalePouls(
        geneticsQuality as string,
        eggProduction as string,
        sortBy as string
      );
      res.json(femalePouls);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch female pouls" });
    }
  });

  // Get Egg Clusters
  app.get("/api/egg-clusters", async (_req, res) => {
    try {
      const eggClusters = await storage.getEggClusters();
      res.json(eggClusters);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch egg clusters" });
    }
  });

  // Get Village Products (hens and eggs)
  app.get("/api/village-products", async (_req, res) => {
    try {
      const villageProducts = await storage.getVillageProducts();
      res.json(villageProducts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch village products" });
    }
  });

  // Get Chicks with optional filters
  app.get("/api/chicks", async (req, res) => {
    try {
      const { ageFilter, sortBy } = req.query;
      const chicks = await storage.getChicks(
        ageFilter as string,
        sortBy as string
      );
      res.json(chicks);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch chicks" });
    }
  });

  // Submit Contact Form
  app.post("/api/contact", async (req, res) => {
    try {
      const contactData = insertContactSchema.parse({
        ...req.body,
        createdAt: new Date().toISOString(),
      });
      
      const contact = await storage.createContact(contactData);
      res.status(201).json(contact);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid form data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to submit contact form" });
      }
    }
  });

  // Create Order
  app.post("/api/orders", async (req, res) => {
    try {
      const orderSchema = z.object({
        customerName: z.string().min(2),
        customerEmail: z.string().email(),
        customerPhone: z.string().optional(),
        address: z.string(),
        items: z.array(z.object({
          id: z.string(),
          name: z.string(),
          price: z.number(),
          quantity: z.number().int().positive(),
        })),
        total: z.number().positive(),
      });

      const orderData = orderSchema.parse({
        ...req.body,
        createdAt: new Date().toISOString(),
        status: "pending",
      });
      
      const order = await storage.createOrder(orderData);
      res.status(201).json(order);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid order data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create order" });
      }
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
