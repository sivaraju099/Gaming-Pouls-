import { 
  users, type User, type InsertUser,
  type InsertContact, type Contact,
  type InsertOrder, type Order,
  type CategoryPreview, type MalePoul, type FemalePoul,
  type EggCluster, type VillageHen, type VillageEgg, type Chick
} from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getCategories(): Promise<CategoryPreview[]>;
  getMalePouls(fightingSkill?: string, weightRange?: string, sortBy?: string): Promise<MalePoul[]>;
  getFemalePouls(geneticsQuality?: string, eggProduction?: string, sortBy?: string): Promise<FemalePoul[]>;
  getEggClusters(): Promise<EggCluster[]>;
  getVillageProducts(): Promise<{ hen: VillageHen; egg: VillageEgg }>;
  getChicks(ageFilter?: string, sortBy?: string): Promise<Chick[]>;
  createContact(contact: InsertContact): Promise<Contact>;
  createOrder(order: InsertOrder): Promise<Order>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private contacts: Map<number, Contact>;
  private orders: Map<number, Order>;
  private categories: CategoryPreview[];
  private malePouls: MalePoul[];
  private femalePouls: FemalePoul[];
  private eggClusters: EggCluster[];
  private villageHen: VillageHen;
  private villageEgg: VillageEgg;
  private chicks: Chick[];
  
  private userCurrentId: number;
  private contactCurrentId: number;
  private orderCurrentId: number;

  constructor() {
    this.users = new Map();
    this.contacts = new Map();
    this.orders = new Map();
    this.userCurrentId = 1;
    this.contactCurrentId = 1;
    this.orderCurrentId = 1;
    
    // Initialize product data
    this.initializeProductData();
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  async getCategories(): Promise<CategoryPreview[]> {
    return this.categories;
  }
  
  async getMalePouls(fightingSkill?: string, weightRange?: string, sortBy?: string): Promise<MalePoul[]> {
    let filteredPouls = [...this.malePouls];
    
    // Apply filtering
    if (fightingSkill) {
      filteredPouls = filteredPouls.filter(poul => poul.skillLevel.toLowerCase() === fightingSkill.toLowerCase());
    }
    
    if (weightRange) {
      switch (weightRange) {
        case 'lightweight':
          filteredPouls = filteredPouls.filter(poul => poul.weight >= 1.5 && poul.weight < 2.0);
          break;
        case 'middleweight':
          filteredPouls = filteredPouls.filter(poul => poul.weight >= 2.0 && poul.weight < 2.5);
          break;
        case 'heavyweight':
          filteredPouls = filteredPouls.filter(poul => poul.weight >= 2.5);
          break;
      }
    }
    
    // Apply sorting
    if (sortBy) {
      switch (sortBy) {
        case 'price-low':
          filteredPouls.sort((a, b) => a.price - b.price);
          break;
        case 'price-high':
          filteredPouls.sort((a, b) => b.price - a.price);
          break;
        case 'newest':
          // Assuming newer items have higher IDs
          filteredPouls.sort((a, b) => b.id.localeCompare(a.id));
          break;
        default: // 'popularity' - no sorting needed as the default order is by popularity
          break;
      }
    }
    
    return filteredPouls;
  }
  
  async getFemalePouls(geneticsQuality?: string, eggProduction?: string, sortBy?: string): Promise<FemalePoul[]> {
    let filteredPouls = [...this.femalePouls];
    
    // Apply filtering
    if (geneticsQuality) {
      filteredPouls = filteredPouls.filter(poul => poul.geneticsQuality.toLowerCase().includes(geneticsQuality.toLowerCase()));
    }
    
    if (eggProduction) {
      switch (eggProduction) {
        case 'low':
          filteredPouls = filteredPouls.filter(poul => poul.eggsPerWeek >= 1 && poul.eggsPerWeek <= 3);
          break;
        case 'medium':
          filteredPouls = filteredPouls.filter(poul => poul.eggsPerWeek >= 4 && poul.eggsPerWeek <= 5);
          break;
        case 'high':
          filteredPouls = filteredPouls.filter(poul => poul.eggsPerWeek >= 6);
          break;
      }
    }
    
    // Apply sorting
    if (sortBy) {
      switch (sortBy) {
        case 'price-low':
          filteredPouls.sort((a, b) => a.price - b.price);
          break;
        case 'price-high':
          filteredPouls.sort((a, b) => b.price - a.price);
          break;
        case 'newest':
          filteredPouls.sort((a, b) => b.id.localeCompare(a.id));
          break;
        default: // 'popularity'
          break;
      }
    }
    
    return filteredPouls;
  }
  
  async getEggClusters(): Promise<EggCluster[]> {
    return this.eggClusters;
  }
  
  async getVillageProducts(): Promise<{ hen: VillageHen; egg: VillageEgg }> {
    return {
      hen: this.villageHen,
      egg: this.villageEgg
    };
  }
  
  async getChicks(ageFilter?: string, sortBy?: string): Promise<Chick[]> {
    let filteredChicks = [...this.chicks];
    
    // Apply filtering
    if (ageFilter) {
      switch (ageFilter) {
        case '1month':
          filteredChicks = filteredChicks.filter(chick => chick.ageInMonths === 1);
          break;
        case '2months':
          filteredChicks = filteredChicks.filter(chick => chick.ageInMonths === 2);
          break;
        case '3months':
          filteredChicks = filteredChicks.filter(chick => chick.ageInMonths === 3);
          break;
        case '4plusmonths':
          filteredChicks = filteredChicks.filter(chick => chick.ageInMonths >= 4);
          break;
      }
    }
    
    // Apply sorting
    if (sortBy) {
      switch (sortBy) {
        case 'price-low':
          filteredChicks.sort((a, b) => a.price - b.price);
          break;
        case 'price-high':
          filteredChicks.sort((a, b) => b.price - a.price);
          break;
        case 'age-young':
          filteredChicks.sort((a, b) => a.ageInMonths - b.ageInMonths);
          break;
        case 'age-old':
          filteredChicks.sort((a, b) => b.ageInMonths - a.ageInMonths);
          break;
      }
    }
    
    return filteredChicks;
  }
  
  async createContact(contactData: InsertContact): Promise<Contact> {
    const id = this.contactCurrentId++;
    const contact = { ...contactData, id };
    this.contacts.set(id, contact);
    return contact;
  }
  
  async createOrder(orderData: InsertOrder): Promise<Order> {
    const id = this.orderCurrentId++;
    const order = { ...orderData, id };
    this.orders.set(id, order);
    return order;
  }
  
  private initializeProductData() {
    // Initialize Categories
    this.categories = [
      {
        id: "1",
        name: "Male Pouls",
        slug: "male-pouls",
        image: "https://pixabay.com/get/g0aaec20498c25291b98b661d4fc6037e4dc1904e369f07a75a317b9b9e15e76031af1879fc7152b8d6d6a26301c88f1e7e63975b13acd3479d0e6f42ea556a19_1280.jpg"
      },
      {
        id: "2",
        name: "Female Pouls",
        slug: "female-pouls",
        image: "https://images.unsplash.com/photo-1548550023-2bdb3c5beed7?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=300"
      },
      {
        id: "3",
        name: "Egg Clusters",
        slug: "egg-clusters",
        image: "https://images.unsplash.com/photo-1598965675045-45c5e72c7d05?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=300"
      },
      {
        id: "4",
        name: "Village Hens",
        slug: "village-hens",
        image: "https://images.unsplash.com/photo-1567201080580-bfcc97dae346?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=300"
      },
      {
        id: "5",
        name: "Chicks",
        slug: "chicks",
        image: "https://pixabay.com/get/g946c9b93511e2b23456f49cdbf6bb4f15c33fcd8503f474a151cb923a0b3dd8ff7f26c402a69f4f3053bf9c3f9d27b9867107a8b9f5cb0c9955dc99a1fff4f27_1280.jpg"
      }
    ];
    
    // Initialize Male Pouls
    this.malePouls = [
      {
        id: "mp1",
        name: "Red Warrior",
        price: 8500,
        image: "https://pixabay.com/get/g7da04adda633d45f119387b1ad688c4396b75c911e4c53616057f7fed4ac3671e0c2afc4cb24d76509216051c7907e7263cede7eb0b05dcab46a08007f010384_1280.jpg",
        description: "Champion bloodline with excellent fighting technique and endurance.",
        skillLevel: "Pro Fighter",
        weight: 2.3,
        age: 1.5,
        wins: 5,
        videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ" // Example URL, would be replaced with actual fight videos
      },
      {
        id: "mp2",
        name: "Golden Phoenix",
        price: 7200,
        image: "https://pixabay.com/get/g3fabbd5391db719161da7bdbb8fb4ed0a21a4c5b7af8acbbf10d0e3bab36cbec2bfce73e2afef84bad21f0c942ecccba3d1f54eb8981caae48359c4cff36305d_1280.jpg",
        description: "Highly agile fighter with excellent reflexes and stamina.",
        skillLevel: "Advanced",
        weight: 2.1,
        age: 1.2,
        wins: 3,
        videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ" // Example URL
      },
      {
        id: "mp3",
        name: "Shadow Hunter",
        price: 5800,
        image: "https://images.unsplash.com/photo-1563281577-a7be47e20db9?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=500&h=350",
        description: "Strong fighter with powerful legs and good offensive strategy.",
        skillLevel: "Intermediate",
        weight: 2.5,
        age: 1.7,
        wins: 2,
        videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ" // Example URL
      },
      {
        id: "mp4",
        name: "Rising Star",
        price: 4200,
        image: "https://pixabay.com/get/g0eea290bdfb0a400799f863e42725982ade69308433f370602bae44d9211e662e6202395fe8b9381209387cfd6f459a8b32a1e3568db92fc5ca859b7417709a2_1280.jpg",
        description: "Young talent with excellent genetics, perfect for training.",
        skillLevel: "Beginner",
        weight: 1.9,
        age: 1.0,
        wins: 0,
        videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ" // Example URL
      }
    ];
    
    // Initialize Female Pouls
    this.femalePouls = [
      {
        id: "fp1",
        name: "Golden Heritage",
        price: 6500,
        image: "https://images.unsplash.com/photo-1612170153139-6f881ff067e0?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=500&h=350",
        description: "Top-tier breeding hen with champion bloodline and consistent egg production.",
        geneticsQuality: "Elite Genetics",
        weight: 1.8,
        age: 1.2,
        eggsPerWeek: 6,
        eggPrice: 120
      },
      {
        id: "fp2",
        name: "Ruby Queen",
        price: 5200,
        image: "https://pixabay.com/get/gec1e811e361c77dbf21412baf106758a82302538f21ef3523c1c474834cde4b68b467e80dd4e56f18d076a0a649a234bc09cf4bb9506ea1aa4a21e2e1e39ee83_1280.jpg",
        description: "Excellent breeder with strong heritage and robust offspring.",
        geneticsQuality: "Premium Genetics",
        weight: 1.7,
        age: 1.4,
        eggsPerWeek: 5,
        eggPrice: 100
      },
      {
        id: "fp3",
        name: "Silver Mist",
        price: 3800,
        image: "https://pixabay.com/get/g031f78f9b39695b71a5d7cbe2164fd49993bf7ea19677f21a583c9bfe19f7aaf887107e8da470ef7e53e6f52c0315a0a7412ea1adfd6231bcb0727c78a8d534d_1280.jpg",
        description: "Good quality breeding hen with reliable egg production.",
        geneticsQuality: "Standard Genetics",
        weight: 1.6,
        age: 1.1,
        eggsPerWeek: 4,
        eggPrice: 80
      },
      {
        id: "fp4",
        name: "Amber Promise",
        price: 3200,
        image: "https://images.unsplash.com/photo-1548550023-2bdb3c5beed7?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=500&h=350",
        description: "Young hen with excellent potential, from premium bloodline.",
        geneticsQuality: "Young Breeder",
        weight: 1.5,
        age: 0.9,
        eggsPerWeek: 3,
        eggPrice: 70
      }
    ];
    
    // Initialize Egg Clusters
    this.eggClusters = [
      {
        id: "ec1",
        name: "Single Egg (1-on-1)",
        count: 1,
        price: 100,
        image: "https://images.unsplash.com/photo-1607355739828-0bf365440db5?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=500&h=350",
        description: "Premium quality egg from champion bloodline.",
        isBestValue: false
      },
      {
        id: "ec2",
        name: "Two Eggs (2-on-1)",
        count: 2,
        price: 200,
        image: "https://images.unsplash.com/photo-1598965675045-45c5e72c7d05?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=500&h=350",
        description: "Set of 2 premium quality eggs from champion bloodline.",
        isBestValue: false
      },
      {
        id: "ec3",
        name: "Four Eggs (4-on-1)",
        count: 4,
        price: 400,
        image: "https://images.unsplash.com/photo-1587486913049-53fc88980cfc?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=500&h=350",
        description: "Set of 4 premium quality eggs from champion bloodline.",
        isBestValue: false
      },
      {
        id: "ec4",
        name: "Six Eggs (6-on-1)",
        count: 6,
        price: 600,
        image: "https://images.unsplash.com/photo-1516448620398-c5f44bf9f441?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=500&h=350",
        description: "Set of 6 premium quality eggs from champion bloodline.",
        isBestValue: false
      },
      {
        id: "ec5",
        name: "Dozen Eggs (12-on-1)",
        count: 12,
        price: 1200,
        image: "https://images.unsplash.com/photo-1544145945-f90425340c7e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=500&h=350",
        description: "Set of 12 premium quality eggs from champion bloodline.",
        isBestValue: true
      }
    ];
    
    // Initialize Village Hen
    this.villageHen = {
      id: "vh1",
      name: "Village Hen",
      description: "Traditional, free-range country hens, naturally raised without antibiotics or hormones. Sold by weight.",
      pricePerKg: 600,
      image: "https://images.unsplash.com/photo-1567201080580-bfcc97dae346?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=700&h=500"
    };
    
    // Initialize Village Egg
    this.villageEgg = {
      id: "ve1",
      name: "Village Eggs",
      description: "Fresh eggs from free-range village hens. Rich in nutrients with deep yellow yolks.",
      pricePerEgg: 25,
      image: "https://pixabay.com/get/g278e899f21fa929b6bdc215ddda6e9242da95b955600eec146d5e5f7bf4c1f0f6919f5568e426c2a2616dc2645111b83b205c13d38f696953aca438a2effea05_1280.jpg"
    };
    
    // Initialize Chicks
    this.chicks = [
      {
        id: "ch1",
        name: "1-Month Chick",
        ageInMonths: 1,
        ageDisplay: "1 month",
        weight: 0.2,
        price: 300,
        image: "https://pixabay.com/get/g2c43aa3b1b5587339725ab5ad5abdf2037606e2d5faccdb37f4bfc8562433852b85b7dbb0598572f90c739c2ecec7a400f1f8a9b0a0bdee7d870157baf855dbb_1280.jpg",
        description: "Healthy chick from champion bloodline, perfect for training."
      },
      {
        id: "ch2",
        name: "2-Month Chick",
        ageInMonths: 2,
        ageDisplay: "2 months",
        weight: 0.4,
        price: 500,
        image: "https://images.unsplash.com/photo-1551884831-bbf3cdc6469e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=500&h=350",
        description: "Growing chick showing excellent development and characteristics."
      },
      {
        id: "ch3",
        name: "3-Month Chick",
        ageInMonths: 3,
        ageDisplay: "3 months",
        weight: 0.7,
        price: 700,
        image: "https://pixabay.com/get/gf2319d08e8a061541edbbd4581c495ae9de1467bc582f491f3faf12e3c0173a4378fe23c97cd76faae29b77228243541aa31abcb6286747717a154b5532f58c9_1280.jpg",
        description: "Well-developed chick beginning to show fighting characteristics."
      },
      {
        id: "ch4",
        name: "4-Month Chick",
        ageInMonths: 4,
        ageDisplay: "4 months",
        weight: 1.0,
        price: 900,
        image: "https://pixabay.com/get/g85caf8b5484d01fb9283f30e6dca623a53ff671a541c8e419648997e23ced0a335f546e6ef6061fd80a7109b0b882557714ed6576d7c784d6027b65f33e867ae_1280.jpg",
        description: "Nearly mature chick ready for advanced training, from champion line."
      }
    ];
  }
}

export const storage = new MemStorage();
